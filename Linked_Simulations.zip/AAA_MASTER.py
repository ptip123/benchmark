import numpy as np
import COMP_3_3_MODEL, TWO_Linear_DES, Unlinked_2_Linear_DES, THREE_Linear_DES, Unlinked_3_Linear_DES
t1 = []
t2 = []
t3 = []
t4 = []
t5=  []
days = 300
def single_model():
    t1.append(COMP_3_3_MODEL.script9_func(days))
def linear_2model():
    t2.append(TWO_Linear_DES.script9_func(days))
def linear_3model():
    t3.append(THREE_Linear_DES.script9_func(days))
def Unlinked_linear_2model():
    t4.append(Unlinked_2_Linear_DES.script9_func(days))
def Unlinked_linear_3model():
    t5.append(Unlinked_3_Linear_DES.script9_func(days))
single_model()
linear_2model()
linear_3model()
Unlinked_linear_2model()
Unlinked_linear_3model()
print(t1,'single model time')
print(t2,'2 model linked time')
print(t3, '3 model linked time')
print(t4, '2 model unlinked time')
print(t5, '3 model unlinked time')
import simpy
from timeit import default_timer as timer
import matplotlib.pyplot as plt
import numpy as np
import time
np.warnings.filterwarnings('ignore', category=np.VisibleDeprecationWarning)
def script9_func(days):

    start = timer()
    print(f'STARTING SIMULATION COMP 3 3 MODEL Three model linked')
    print(f'CALCULATING')

    # -------------------------------------------------
    # Parameters
    #------------------------------------------------
    #####time######
    #minutes in hour
    minutes = 60
    # working hours
    hours = 8
    # business days
    # total working time (hours)
    total_time = hours * days * minutes
    #-------------------------------------------------
    #Distribution of cycle timings
    #spread of timings
    sigma = 0.5
    #-------------------------------------------------
    #####containers#####
    store_capacity = 100000
    initial_qty = 100000
    dispatch_capacity =100000
    queue_capacity = 1
    queue_init_qty = 1
    #-------------------------------------------------
    #process times
    # Process 1
    mean_model1_process1_time = 10
    mean_model2_process1_time = 12
    mean_model3_process1_time = 13

    # Process 2
    mean_model1_process2_time = 8
    mean_model2_process2_time = 9
    mean_model3_process2_time = 10

    # Process 3
    mean_model1_process3_time = 6
    mean_model2_process3_time = 6
    mean_model3_process3_time = 6

    # Process 4
    mean_model1_process4_time = 12
    mean_model2_process4_time = 15
    mean_model3_process4_time = 17

    # Process 5
    mean_model1_process5_time = 10
    mean_model2_process5_time = 8
    mean_model3_process5_time = 9

    # Process 6
    mean_model1_process6_time = 15
    mean_model2_process6_time = 12
    mean_model3_process6_time = 13

    # Process 7
    mean_model1_process7_time = 10
    mean_model2_process7_time = 8
    mean_model3_process7_time = 9

    # Process 8
    mean_model1_process8_time = 6
    mean_model2_process8_time = 5
    mean_model3_process8_time = 5

    # Process 9
    mean_model1_process9_time = 8
    mean_model2_process9_time = 10
    mean_model3_process9_time = 11

    # Process 10
    mean_model1_process10_time = 14
    mean_model2_process10_time = 11
    mean_model3_process10_time = 12

    # Process 11
    mean_model1_process11_time = 11
    mean_model2_process11_time = 8
    mean_model3_process11_time = 9

    # Process 12
    mean_model1_process12_time = 13
    mean_model2_process12_time = 12
    mean_model3_process12_time = 13
    # Process 13
    mean_model1_process13_time = 18
    mean_model2_process13_time = 15
    mean_model3_process13_time = 13
    # Process 14
    mean_model1_process14_time = 6
    mean_model2_process14_time = 4
    mean_model3_process14_time = 4
    # Process 15
    mean_model1_process15_time = 15
    mean_model2_process15_time = 12
    mean_model3_process15_time = 13
    # Process 16
    mean_model1_process16_time = 14
    mean_model2_process16_time = 16
    mean_model3_process16_time = 18
    # Process 17
    mean_model1_process17_time = 13
    mean_model2_process17_time = 10
    mean_model3_process17_time = 11
    # Process 18
    mean_model1_process18_time = 9
    mean_model2_process18_time = 7
    mean_model3_process18_time = 8
    # Process 19
    mean_model1_process19_time = 7
    mean_model2_process19_time = 9
    mean_model3_process19_time = 10
    # Process 20
    mean_model1_process20_time = 12
    mean_model2_process20_time = 9
    mean_model3_process20_time = 10
    # Process 21
    mean_model1_process21_time = 8
    mean_model2_process21_time = 6
    mean_model3_process21_time = 6
    # Process 22
    mean_model1_process22_time = 11
    mean_model2_process22_time = 10
    mean_model3_process22_time = 11
    # Process 23
    mean_model1_process23_time = 6
    mean_model2_process23_time = 4
    mean_model3_process23_time = 4
    # Process 24
    mean_model1_process24_time = 16
    mean_model2_process24_time = 12
    mean_model3_process24_time = 13
    # Process 25
    mean_model1_process25_time = 12
    mean_model2_process25_time = 11
    mean_model3_process25_time = 12
    # Process 26
    mean_model1_process26_time = 6
    mean_model2_process26_time = 4
    mean_model3_process26_time = 4
    # Process 27
    mean_model1_process27_time = 8
    mean_model2_process27_time = 6
    mean_model3_process27_time = 6
    # Process 28
    mean_model1_process28_time = 11
    mean_model2_process28_time = 9
    mean_model3_process28_time = 10
    # Process 29
    mean_model1_process29_time = 12
    mean_model2_process29_time = 9
    mean_model3_process29_time = 10
    # Process 30
    mean_model1_process30_time = 7
    mean_model2_process30_time = 5
    mean_model3_process30_time = 5
    # Process 31
    mean_model1_process31_time = 5
    mean_model2_process31_time = 6
    mean_model3_process31_time = 6
    # Process 32
    mean_model1_process32_time = 11
    mean_model2_process32_time = 8
    mean_model3_process32_time = 9
    # Process 33
    mean_model1_process33_time = 13
    mean_model2_process33_time = 10
    mean_model3_process33_time = 11
    # Process 34
    mean_model1_process34_time = 11
    mean_model2_process34_time = 12
    mean_model3_process34_time = 13
    # Process 35
    mean_model1_process35_time = 9
    mean_model2_process35_time = 7
    mean_model3_process35_time = 8
    # Process 36
    mean_model1_process36_time = 6
    mean_model2_process36_time = 9
    mean_model3_process36_time = 10
    # Process 37
    mean_model1_process37_time = 17
    mean_model2_process37_time = 13
    mean_model3_process37_time = 14
    # Process 38
    mean_model1_process38_time = 12
    mean_model2_process38_time = 9
    mean_model3_process38_time = 10
    # Process 39
    mean_model1_process39_time = 14
    mean_model2_process39_time = 14
    mean_model3_process39_time = 16
    # Process 40
    mean_model1_process40_time = 6
    mean_model2_process40_time = 4
    mean_model3_process40_time = 4
    #----------------------------------------------------
    ################## PLOT VARIABLES ################
    # Process 1
    model1_process1_time = np.random.normal(mean_model1_process1_time, sigma, 1)
    model2_process1_time = np.random.normal(mean_model2_process1_time, sigma, 1)
    model3_process1_time = np.random.normal(mean_model3_process1_time, sigma, 1)

    # Process 2
    model1_process2_time = np.random.normal(mean_model1_process2_time, sigma, 1)
    model2_process2_time = np.random.normal(mean_model2_process2_time, sigma, 1)
    model3_process2_time = np.random.normal(mean_model3_process2_time, sigma, 1)

    # Process 3
    model1_process3_time = np.random.normal(mean_model1_process3_time, sigma, 1)
    model2_process3_time = np.random.normal(mean_model2_process3_time, sigma, 1)
    model3_process3_time = np.random.normal(mean_model3_process3_time, sigma, 1)

    # Process 4
    model1_process4_time = np.random.normal(mean_model1_process4_time, sigma, 1)
    model2_process4_time = np.random.normal(mean_model2_process4_time, sigma, 1)
    model3_process4_time = np.random.normal(mean_model3_process4_time, sigma, 1)

    # Process 5
    model1_process5_time = np.random.normal(mean_model1_process5_time, sigma, 1)
    model2_process5_time = np.random.normal(mean_model2_process5_time, sigma, 1)
    model3_process5_time = np.random.normal(mean_model3_process5_time, sigma, 1)

    # Process 6
    model1_process6_time = np.random.normal(mean_model1_process6_time, sigma, 1)
    model2_process6_time = np.random.normal(mean_model2_process6_time, sigma, 1)
    model3_process6_time = np.random.normal(mean_model3_process6_time, sigma, 1)

    # Process 7
    model1_process7_time = np.random.normal(mean_model1_process7_time, sigma, 1)
    model2_process7_time = np.random.normal(mean_model2_process7_time, sigma, 1)
    model3_process7_time = np.random.normal(mean_model3_process7_time, sigma, 1)

    # Process 8
    model1_process8_time = np.random.normal(mean_model1_process8_time, sigma, 1)
    model2_process8_time = np.random.normal(mean_model2_process8_time, sigma, 1)
    model3_process8_time = np.random.normal(mean_model3_process8_time, sigma, 1)

    # Process 9
    model1_process9_time =  np.random.normal(mean_model1_process9_time, sigma, 1)
    model2_process9_time =  np.random.normal(mean_model2_process9_time, sigma, 1)
    model3_process9_time =  np.random.normal(mean_model3_process9_time, sigma, 1)

    # Process 10
    model1_process10_time =  np.random.normal(mean_model1_process10_time, sigma, 1)
    model2_process10_time =  np.random.normal(mean_model2_process10_time, sigma, 1)
    model3_process10_time =  np.random.normal(mean_model3_process10_time, sigma, 1)


    # Process 11
    model1_process11_time =  np.random.normal(mean_model1_process11_time, sigma, 1)
    model2_process11_time =  np.random.normal(mean_model2_process11_time, sigma, 1)
    model3_process11_time =  np.random.normal(mean_model3_process11_time, sigma, 1)
    # Process 12
    model1_process12_time =  np.random.normal(mean_model1_process12_time, sigma, 1)
    model2_process12_time =  np.random.normal(mean_model2_process12_time, sigma, 1)
    model3_process12_time =  np.random.normal(mean_model3_process12_time, sigma, 1)

    # Process 13
    model1_process13_time = np.random.normal(mean_model1_process13_time, sigma, 1)
    model2_process13_time = np.random.normal(mean_model2_process13_time, sigma, 1)
    model3_process13_time = np.random.normal(mean_model3_process13_time, sigma, 1)
    # Process 14
    model1_process14_time = np.random.normal(mean_model1_process14_time, sigma, 1)
    model2_process14_time = np.random.normal(mean_model2_process14_time, sigma, 1)
    model3_process14_time = np.random.normal(mean_model3_process14_time, sigma, 1)
    # Process 15
    model1_process15_time = np.random.normal(mean_model1_process15_time, sigma, 1)
    model2_process15_time = np.random.normal(mean_model2_process15_time, sigma, 1)
    model3_process15_time = np.random.normal(mean_model3_process15_time, sigma, 1)
    # Process 16
    model1_process16_time = np.random.normal(mean_model1_process16_time, sigma, 1)
    model2_process16_time = np.random.normal(mean_model2_process16_time, sigma, 1)
    model3_process16_time = np.random.normal(mean_model3_process16_time, sigma, 1)
    # Process 17
    model1_process17_time = np.random.normal(mean_model1_process17_time, sigma, 1)
    model2_process17_time = np.random.normal(mean_model2_process17_time, sigma, 1)
    model3_process17_time = np.random.normal(mean_model3_process17_time, sigma, 1)

    # Process 18
    model1_process18_time = np.random.normal(mean_model1_process18_time, sigma, 1)
    model2_process18_time = np.random.normal(mean_model2_process18_time, sigma, 1)
    model3_process18_time = np.random.normal(mean_model3_process18_time, sigma, 1)

    # Process 19
    model1_process19_time = np.random.normal(mean_model1_process19_time, sigma, 1)
    model2_process19_time = np.random.normal(mean_model2_process19_time, sigma, 1)
    model3_process19_time = np.random.normal(mean_model3_process19_time, sigma, 1)

    # Process 20
    model1_process20_time = np.random.normal(mean_model1_process20_time, sigma, 1)
    model2_process20_time = np.random.normal(mean_model2_process20_time, sigma, 1)
    model3_process20_time = np.random.normal(mean_model3_process20_time, sigma, 1)

    # Process 21
    model1_process21_time = np.random.normal(mean_model1_process21_time, sigma, 1)
    model2_process21_time = np.random.normal(mean_model2_process21_time, sigma, 1)
    model3_process21_time = np.random.normal(mean_model3_process21_time, sigma, 1)

    # Process 22
    model1_process22_time = np.random.normal(mean_model1_process22_time, sigma, 1)
    model2_process22_time = np.random.normal(mean_model2_process22_time, sigma, 1)
    model3_process22_time = np.random.normal(mean_model3_process22_time, sigma, 1)

    # Process 23
    model1_process23_time = np.random.normal(mean_model1_process23_time, sigma, 1)
    model2_process23_time = np.random.normal(mean_model2_process23_time, sigma, 1)
    model3_process23_time = np.random.normal(mean_model3_process23_time, sigma, 1)

    # Process 24
    model1_process24_time = np.random.normal(mean_model1_process24_time, sigma, 1)
    model2_process24_time = np.random.normal(mean_model2_process24_time, sigma, 1)
    model3_process24_time = np.random.normal(mean_model3_process24_time, sigma, 1)

    # Process 25
    model1_process25_time = np.random.normal(mean_model1_process25_time, sigma, 1)
    model2_process25_time = np.random.normal(mean_model2_process25_time, sigma, 1)
    model3_process25_time = np.random.normal(mean_model3_process25_time, sigma, 1)

    # Process 26
    model1_process26_time = np.random.normal(mean_model1_process26_time, sigma, 1)
    model2_process26_time = np.random.normal(mean_model2_process26_time, sigma, 1)
    model3_process26_time = np.random.normal(mean_model3_process26_time, sigma, 1)

    # Process 27
    model1_process27_time = np.random.normal(mean_model1_process27_time, sigma, 1)
    model2_process27_time = np.random.normal(mean_model2_process27_time, sigma, 1)
    model3_process27_time = np.random.normal(mean_model3_process27_time, sigma, 1)

    # Process 28
    model1_process28_time = np.random.normal(mean_model1_process28_time, sigma, 1)
    model2_process28_time = np.random.normal(mean_model2_process28_time, sigma, 1)
    model3_process28_time = np.random.normal(mean_model3_process28_time, sigma, 1)

    # Process 29
    model1_process29_time = np.random.normal(mean_model1_process29_time, sigma, 1)
    model2_process29_time = np.random.normal(mean_model2_process29_time, sigma, 1)
    model3_process29_time = np.random.normal(mean_model3_process29_time, sigma, 1)

    # Process 30
    model1_process30_time = np.random.normal(mean_model1_process30_time, sigma, 1)
    model2_process30_time = np.random.normal(mean_model2_process30_time, sigma, 1)
    model3_process30_time = np.random.normal(mean_model3_process30_time, sigma, 1)

    # Process 31
    model1_process31_time = np.random.normal(mean_model1_process31_time, sigma, 1)
    model2_process31_time = np.random.normal(mean_model2_process31_time, sigma, 1)
    model3_process31_time = np.random.normal(mean_model3_process31_time, sigma, 1)

    # Process 32
    model1_process32_time = np.random.normal(mean_model1_process32_time, sigma, 1)
    model2_process32_time = np.random.normal(mean_model2_process32_time, sigma, 1)
    model3_process32_time = np.random.normal(mean_model3_process32_time, sigma, 1)

    # Process 33
    model1_process33_time = np.random.normal(mean_model1_process33_time, sigma, 1)
    model2_process33_time = np.random.normal(mean_model2_process33_time, sigma, 1)
    model3_process33_time = np.random.normal(mean_model3_process33_time, sigma, 1)

    # Process 34
    model1_process34_time = np.random.normal(mean_model1_process34_time, sigma, 1)
    model2_process34_time = np.random.normal(mean_model2_process34_time, sigma, 1)
    model3_process34_time = np.random.normal(mean_model3_process34_time, sigma, 1)

    # Process 35
    model1_process35_time = np.random.normal(mean_model1_process35_time, sigma, 1)
    model2_process35_time = np.random.normal(mean_model2_process35_time, sigma, 1)
    model3_process35_time = np.random.normal(mean_model3_process35_time, sigma, 1)

    # Process 36
    model1_process36_time = np.random.normal(mean_model1_process36_time, sigma, 1)
    model2_process36_time = np.random.normal(mean_model2_process36_time, sigma, 1)
    model3_process36_time = np.random.normal(mean_model3_process36_time, sigma, 1)

    # Process 37
    model1_process37_time = np.random.normal(mean_model1_process37_time, sigma, 1)
    model2_process37_time = np.random.normal(mean_model2_process37_time, sigma, 1)
    model3_process37_time = np.random.normal(mean_model3_process37_time, sigma, 1)

    # Process 38
    model1_process38_time = np.random.normal(mean_model1_process38_time, sigma, 1)
    model2_process38_time = np.random.normal(mean_model2_process38_time, sigma, 1)
    model3_process38_time = np.random.normal(mean_model3_process38_time, sigma, 1)

    # Process 39
    model1_process39_time = np.random.normal(mean_model1_process39_time, sigma, 1)
    model2_process39_time = np.random.normal(mean_model2_process39_time, sigma, 1)
    model3_process39_time = np.random.normal(mean_model3_process39_time, sigma, 1)

    # Process 40
    model1_process40_time = np.random.normal(mean_model1_process40_time, sigma, 1)
    model2_process40_time = np.random.normal(mean_model2_process40_time, sigma, 1)
    model3_process40_time = np.random.normal(mean_model3_process40_time, sigma, 1)

    #-----------------------------------------------------
    #Plot variables
    x1 = []
    x2 = []
    x3 = []
    x4 = []
    x5 = []
    x6 = []
    x7 = []
    x8 = []
    x9 = []
    x10 = []
    x11 = []
    x12 = []
    x13 = []
    x14 = []
    x15 = []
    x16 = []
    x17 = []
    x18 = []
    x19 = []
    x20 = []
    x21 = []
    x22 = []
    x23 = []
    x24 = []
    x25 = []
    x26 = []
    x27 = []
    x28 = []
    x29 = []
    x30 = []
    x31 = []
    x32 = []
    x33 = []
    x34 = []
    x35 = []
    x36 = []
    x37 = []
    x38 = []
    x39 = []
    x40 = []
    x41 = []
    y1 = []
    y2 = []
    y3 = []
    y4 = []
    y5 = []
    y6 = []
    y7 = []
    y8 = []
    y9 = []
    y10 = []
    y11 = []
    y12 = []
    y13 = []
    y14 = []
    y15 = []
    y16 = []
    y17 = []
    y18 = []
    y19 = []
    y20 = []
    y21 = []
    y22 = []
    y23 = []
    y24 = []
    y25 = []
    y26 = []
    y27 = []
    y28 = []
    y29 = []
    y30 = []
    y31 = []
    y32 = []
    y33 = []
    y34 = []
    y35 = []
    y36 = []
    y37 = []
    y38 = []
    y39 = []
    y40 = []
    y41 = []

    #-------------------------------------------------------------------------------------

    class Factory:
        def __init__(self,env):
            self.material1 = simpy.Container(env, capacity=store_capacity, init=initial_qty)
            self.material2 = simpy.Container(env, capacity=store_capacity, init=initial_qty)
            self.dispatch = simpy.Container(env, capacity=dispatch_capacity, init=0)
            self.queue1 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.queue2 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.queue3 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.queue4 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.queue5 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.queue6 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.queue7 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.queue8 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.queue9 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.queue10 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.queue11 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.queue12 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.queue13 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.queue14 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.queue15 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.queue16 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.queue17 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.queue18 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.queue19 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.queue20 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.queue21 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.queue22 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.queue23 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.queue24 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.queue25 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.queue26 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.queue27 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.queue28 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.queue29 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.queue30 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.queue31 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.queue32 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.queue33 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.queue34 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.queue35 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.queue36 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.queue37 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.queue38 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.queue39 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.queue40 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.queue41 = simpy.Container(env, capacity=store_capacity, init=0)
            self.queue42 = simpy.Container(env, capacity=store_capacity, init=0)
            self.count1 = 1
            self.count2 = 1
            self.count3 = 1
            self.count4 = 1
            self.count5 = 1
            self.count6 = 1
            self.count7 = 1
            self.count8 = 1
            self.count9 = 1
            self.count10 = 1
            self.count11 = 1
            self.count12 = 1
            self.count13 = 1
            self.count14 = 1
            self.count15 = 1
            self.count16 = 1
            self.count17 = 1
            self.count18 = 1
            self.count19 = 1
            self.count20 = 1
            self.count21 = 1
            self.count22 = 1
            self.count23 = 1
            self.count24 = 1
            self.count25 = 1
            self.count26 = 1
            self.count27 = 1
            self.count28 = 1
            self.count29 = 1
            self.count30 = 1
            self.count31 = 1
            self.count32 = 1
            self.count33 = 1
            self.count34 = 1
            self.count35 = 1
            self.count36 = 1
            self.count37 = 1
            self.count38 = 1
            self.count39 = 1
            self.count40 = 1
            self.count41 = 1
            self.model1 = 0
            self.model2 = 0
            self.model3 = 0
            self.Bqueue1 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Bqueue2 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Bqueue3 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Bqueue4 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Bqueue5 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Bqueue6 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Bqueue7 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Bqueue8 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Bqueue9 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Bqueue10 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Bqueue11 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Bqueue12 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Bqueue13 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Bqueue14 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Bqueue15 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Bqueue16 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Bqueue17 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Bqueue18 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Bqueue19 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Bqueue20 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Bqueue21 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Bqueue22 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Bqueue23 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Bqueue24 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Bqueue25 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Bqueue26 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Bqueue27 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Bqueue28 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Bqueue29 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Bqueue30 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Bqueue31 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Bqueue32 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Bqueue33 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Bqueue34 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Bqueue35 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Bqueue36 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Bqueue37 = simpy.Container(env, capacity=queue_capacity, init=0)
            self.Bqueue38 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Bqueue39 = simpy.Container(env, capacity=queue_capacity, init=0)
            self.Bqueue40 = simpy.Container(env, capacity=queue_capacity, init=0)
            self.Bqueue41 = simpy.Container(env, capacity=store_capacity, init=0)
            self.Bcount1 = 1
            self.Bcount2 = 1
            self.Bcount3 = 1
            self.Bcount4 = 1
            self.Bcount5 = 1
            self.Bcount6 = 1
            self.Bcount7 = 1
            self.Bcount8 = 1
            self.Bcount9 = 1
            self.Bcount10 = 1
            self.Bcount11 = 1
            self.Bcount12 = 1
            self.Bcount13 = 1
            self.Bcount14 = 1
            self.Bcount15 = 1
            self.Bcount16 = 1
            self.Bcount17 = 1
            self.Bcount18 = 1
            self.Bcount19 = 1
            self.Bcount20 = 1
            self.Bcount21 = 1
            self.Bcount22 = 1
            self.Bcount23 = 1
            self.Bcount24 = 1
            self.Bcount25 = 1
            self.Bcount26 = 1
            self.Bcount27 = 1
            self.Bcount28 = 1
            self.Bcount29 = 1
            self.Bcount30 = 1
            self.Bcount31 = 1
            self.Bcount32 = 1
            self.Bcount33 = 1
            self.Bcount34 = 1
            self.Bcount35 = 1
            self.Bcount36 = 1
            self.Bcount37 = 1
            self.Bcount38 = 1
            self.Bcount39 = 1
            self.Bcount40 = 1
            self.Bcount41 = 1
            self.Cqueue1 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Cqueue2 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Cqueue3 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Cqueue4 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Cqueue5 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Cqueue6 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Cqueue7 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Cqueue8 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Cqueue9 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Cqueue10 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Cqueue11 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Cqueue12 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Cqueue13 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Cqueue14 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Cqueue15 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Cqueue16 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Cqueue17 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Cqueue18 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Cqueue19 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Cqueue20 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Cqueue21 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Cqueue22 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Cqueue23 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Cqueue24 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Cqueue25 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Cqueue26 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Cqueue27 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Cqueue28 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Cqueue29 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Cqueue30 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Cqueue31 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Cqueue32 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Cqueue33 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Cqueue34 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Cqueue35 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Cqueue36 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Cqueue37 = simpy.Container(env, capacity=queue_capacity, init=0)
            self.Cqueue38 = simpy.Container(env, capacity=queue_capacity, init=queue_init_qty)
            self.Cqueue39 = simpy.Container(env, capacity=queue_capacity, init=0)
            self.Cqueue40 = simpy.Container(env, capacity=queue_capacity, init=0)
            self.Ccount1 = 1
            self.Ccount2 = 1
            self.Ccount3 = 1
            self.Ccount4 = 1
            self.Ccount5 = 1
            self.Ccount6 = 1
            self.Ccount7 = 1
            self.Ccount8 = 1
            self.Ccount9 = 1
            self.Ccount10 = 1
            self.Ccount11 = 1
            self.Ccount12 = 1
            self.Ccount13 = 1
            self.Ccount14 = 1
            self.Ccount15 = 1
            self.Ccount16 = 1
            self.Ccount17 = 1
            self.Ccount18 = 1
            self.Ccount19 = 1
            self.Ccount20 = 1
            self.Ccount21 = 1
            self.Ccount22 = 1
            self.Ccount23 = 1
            self.Ccount24 = 1
            self.Ccount25 = 1
            self.Ccount26 = 1
            self.Ccount27 = 1
            self.Ccount28 = 1
            self.Ccount29 = 1
            self.Ccount30 = 1
            self.Ccount31 = 1
            self.Ccount32 = 1
            self.Ccount33 = 1
            self.Ccount34 = 1
            self.Ccount35 = 1
            self.Ccount36 = 1
            self.Ccount37 = 1
            self.Ccount38 = 1
            self.Ccount39 = 1
            self.Ccount40 = 1
            self.Ccount41 = 1
            self.pc1 = 0
            self.pc2 = 0
            self.pc3 = 0
            self.pc4 = 0
            self.pc5 = 0
            self.pc6 = 0
            self.pc7 = 0
            self.pc8 = 0
            self.pc9 = 0
            self.pc10 = 0
            self.pc11 = 0
            self.pc12 = 0
            self.pc13 = 0
            self.pc14 = 0
            self.pc14 = 0
            self.pc15 = 0
            self.pc16 = 0
            self.pc17 = 0
            self.pc18 = 0
            self.pc19 = 0
            self.pc20 = 0
            self.pc21 = 0
            self.pc22 = 0
            self.pc23 = 0
            self.pc24 = 0
            self.pc25 = 0
            self.pc26 = 0
            self.pc27 = 0
            self.pc28 = 0
            self.pc29 = 0
            self.pc30 = 0
            self.pc31 = 0
            self.pc32 = 0
            self.pc33 = 0
            self.pc34 = 0
            self.pc35 = 0
            self.pc36 = 0
            self.pc37 = 0
            self.pc38 = 0
            self.pc39 = 0
            self.pc40 = 0
            self.pc41 = 0


    env = simpy.Environment()
    factory = Factory(env)
    #------------------------------------------------------------------------------------------
    #Processes
    def process1(env,factory):
        while True:
            yield factory.material1.get(1)
            if factory.count1 == 1:
                yield env.timeout(model1_process1_time)
                factory.count1 += 1
            elif factory.count1 == 2:
                yield env.timeout(model2_process1_time)
                factory.count1 += 1
            elif factory.count1 == 3:
                yield env.timeout(model3_process1_time)
                factory.count1 = 1
            else:
                print("count1 error")
                raise SystemExit(0)
            yield factory.queue1.put(1)
            factory.pc1 += 1
            # x1.append(float(env.now))
            # y1.append(factory.queue1.level)

    def process2(env,factory):
        while True:
            yield factory.material2.get(1)
            if factory.count2 == 1:
                yield env.timeout(model1_process2_time)
                factory.count2 += 1
            elif factory.count2 == 2:
                yield env.timeout(model2_process2_time)
                factory.count2 += 1
            elif factory.count2 == 3:
                yield env.timeout(model3_process2_time)
                factory.count2 = 1
            else:
                print("count2 error")
                raise SystemExit(0)
            yield factory.queue2.put(1)
            factory.pc2 += 1
            # x2.append(float(env.now))
            # y2.append(factory.queue2.level)

    def process3(env,factory):
        while True:
            yield factory.queue1.get(1)
            yield factory.queue2.get(1)
            if factory.count3 == 1:
                yield env.timeout(model1_process3_time)
                factory.count3 += 1
            elif factory.count3 == 2:
                yield env.timeout(model2_process3_time)
                factory.count3 += 1
            elif factory.count3 == 3:
                yield env.timeout(model3_process3_time)
                factory.count3 = 1
            else:
                print("count3 error")
                raise SystemExit(0)
            yield factory.queue3.put(1)
            factory.pc3 += 1
            # x3.append(float(env.now))
            # y3.append(factory.queue3.level)

    def process4(env,factory):
        while True:
            yield factory.queue1.get(1)
            if factory.count4 == 1:
                yield env.timeout(model1_process4_time)
                factory.count4 += 1
            elif factory.count4 == 2:
                yield env.timeout(model2_process4_time)
                factory.count4 += 1
            elif factory.count4 == 3:
                yield env.timeout(model3_process4_time)
                factory.count4 = 1
            else:
                print("count4 error")
                raise SystemExit(0)
            yield factory.queue4.put(1)
            factory.pc4 += 1
            # x4.append(float(env.now))
            # y4.append(factory.queue4.level)

    def process5(env,factory):
        while True:
            yield factory.queue4.get(1)
            if factory.count5 == 1:
                yield env.timeout(model1_process5_time)
                factory.count5 += 1
            elif factory.count5 == 2:
                yield env.timeout(model2_process5_time)
                factory.count5 += 1
            elif factory.count5 == 3:
                yield env.timeout(model3_process5_time)
                factory.count5 = 1
            else:
                print("count5 error")
                raise SystemExit(0)
            yield factory.queue5.put(1)
            factory.pc5 += 1
            # x5.append(float(env.now))
            # y5.append(factory.queue5.level)

    def process6(env,factory):
        while True:
            yield factory.queue3.get(1)
            if factory.count6 == 1:
                yield env.timeout(model1_process6_time)
                factory.count6 += 1
            elif factory.count6 == 2:
                yield env.timeout(model2_process6_time)
                factory.count6 += 1
            elif factory.count6 == 3:
                yield env.timeout(model3_process6_time)
                factory.count6 = 1
            else:
                print("count6 error")
                raise SystemExit(0)
            yield factory.queue6.put(1)
            factory.pc6 += 1
            # x6.append(float(env.now))
            # y6.append(factory.queue6.level)

    def process7(env,factory):
        while True:
            yield factory.queue2.get(1)
            if factory.count7 == 1:
                yield env.timeout(model1_process7_time)
                factory.count7 += 1
            elif factory.count7 == 2:
                yield env.timeout(model2_process7_time)
                factory.count7 += 1
            elif factory.count7 == 3:
                yield env.timeout(model3_process7_time)
                factory.count7 = 1
            else:
                print("count7 error")
                raise SystemExit(0)
            yield factory.queue7.put(1)
            factory.pc7 += 1
            # x7.append(float(env.now))
            # y7.append(factory.queue7.level)

    def process8(env,factory):
        while True:
            yield factory.queue7.get(1)
            if factory.count8 == 1:
                yield env.timeout(model1_process8_time)
                factory.count8 += 1
            elif factory.count8 == 2:
                yield env.timeout(model2_process8_time)
                factory.count8+= 1
            elif factory.count8 == 3:
                yield env.timeout(model3_process8_time)
                factory.count8 = 1
            else:
                print("count8 error")
                raise SystemExit(0)
            yield factory.queue8.put(1)
            factory.pc8 += 1
            # x8.append(float(env.now))
            # y8.append(factory.queue8.level)

    def process9(env,factory):
        while True:
            yield factory.queue7.get(1)
            if factory.count9 == 1:
                yield env.timeout(model1_process9_time)
                factory.count9 += 1
            elif factory.count9 == 2:
                yield env.timeout(model2_process9_time)
                factory.count9 += 1
            elif factory.count9 == 3:
                yield env.timeout(model3_process9_time)
                factory.count9 = 1
            else:
                print("count9 error")
                raise SystemExit(0)
            yield factory.queue9.put(1)
            factory.pc9 += 1
            # x9.append(float(env.now))
            # y9.append(factory.queue9.level)

    def process10(env,factory):
        while True:
            yield factory.queue8.get(1)
            yield factory.queue9.get(1)
            if factory.count10 == 1:
                yield env.timeout(model1_process10_time)
                factory.count10 += 1
            elif factory.count10 == 2:
                yield env.timeout(model2_process10_time)
                factory.count10 += 1
            elif factory.count10 == 3:
                yield env.timeout(model3_process10_time)
                factory.count10 = 1
            else:
                print("count10 error")
                raise SystemExit(0)
            yield factory.queue10.put(1)
            factory.pc10 += 1
            # x10.append(float(env.now))
            # y10.append(factory.queue10.level)

    def process11(env,factory):
        while True:
            yield factory.queue6.get(1)
            if factory.count11 == 1:
                yield env.timeout(model1_process11_time)
                factory.count11 += 1
            elif factory.count11 == 2:
                yield env.timeout(model2_process11_time)
                factory.count11 += 1
            elif factory.count11 == 3:
                yield env.timeout(model3_process11_time)
                factory.count11 = 1
            else:
                print("count11 error")
                raise SystemExit(0)
            yield factory.queue11.put(1)
            factory.pc11 += 1
            # x11.append(float(env.now))
            # y11.append(factory.queue11.level)

    def process12(env,factory):
        while True:
            yield factory.queue5.get(1)
            if factory.count12 == 1:
                yield env.timeout(model1_process12_time)
                factory.count12 += 1
            elif factory.count12 == 2:
                yield env.timeout(model2_process12_time)
                factory.count12 += 1
            elif factory.count12 == 3:
                yield env.timeout(model3_process12_time)
                factory.count12 = 1
            else:
                print("count12 error")
                raise SystemExit(0)
            yield factory.queue12.put(1)
            factory.pc12 += 1
            # x12.append(float(env.now))
            # y12.append(factory.queue12.level)

    def process13(env,factory):
        while True:
            yield factory.queue5.get(1)
            if factory.count13 == 1:
                yield env.timeout(model1_process13_time)
                factory.count13 += 1
            elif factory.count13 == 2:
                yield env.timeout(model2_process13_time)
                factory.count13 += 1
            elif factory.count13 == 3:
                yield env.timeout(model3_process13_time)
                factory.count13 = 1
            else:
                print("count13 error")
                raise SystemExit(0)
            yield factory.queue13.put(1)
            factory.pc13 += 1
            # x13.append(float(env.now))
            # y13.append(factory.queue13.level)


    def process14(env,factory):
        while True:
            yield factory.queue11.get(1)
            yield factory.queue13.get(1)
            if factory.count14 == 1:
                yield env.timeout(model1_process14_time)
                factory.count14 += 1
            elif factory.count14 == 2:
                yield env.timeout(model2_process14_time)
                factory.count14 += 1
            elif factory.count14 == 3:
                yield env.timeout(model3_process14_time)
                factory.count14 = 1
            else:
                print("count14 error")
                raise SystemExit(0)
            yield factory.queue14.put(1)
            factory.pc14 += 1
            # x14.append(float(env.now))
            # y14.append(factory.queue14.level)

    def process15(env,factory):
        while True:
            yield factory.queue12.get(1)
            if factory.count15 == 1:
                yield env.timeout(model1_process15_time)
                factory.count15 += 1
            elif factory.count15 == 2:
                yield env.timeout(model2_process15_time)
                factory.count15 += 1
            elif factory.count15 == 3:
                yield env.timeout(model3_process15_time)
                factory.count15 = 1
            else:
                print("count15 error")
                raise SystemExit(0)
            yield factory.queue15.put(1)
            factory.pc15 += 1
            # x15.append(float(env.now))
            # y15.append(factory.queue15.level)


    def process16(env,factory):
        while True:
            yield factory.queue10.get(1)
            if factory.count16 == 1:
                yield env.timeout(model1_process16_time)
                factory.count16 += 1
            elif factory.count16 == 2:
                yield env.timeout(model2_process16_time)
                factory.count16 += 1
            elif factory.count16 == 3:
                yield env.timeout(model3_process16_time)
                factory.count16 = 1
            else:
                print("count16 error")
                raise SystemExit(0)
            yield factory.queue16.put(1)
            factory.pc16 += 1
            # x16.append(float(env.now))
            # y16.append(factory.queue16.level)

    def process17(env,factory):
        while True:
            yield factory.queue15.get(1)
            yield factory.queue14.get(1)
            if factory.count17 == 1:
                yield env.timeout(model1_process17_time)
                factory.count17 += 1
            elif factory.count17 == 2:
                yield env.timeout(model2_process17_time)
                factory.count17 += 1
            elif factory.count17 == 3:
                yield env.timeout(model3_process17_time)
                factory.count17 = 1
            else:
                print("count17 error")
                raise SystemExit(0)
            yield factory.queue17.put(1)
            factory.pc17 += 1
            # x17.append(float(env.now))
            # y17.append(factory.queue17.level)

    def process18(env,factory):
        while True:
            yield factory.queue16.get(1)
            if factory.count18 == 1:
                yield env.timeout(model1_process18_time)
                factory.count18 += 1
            elif factory.count18 == 2:
                yield env.timeout(model2_process18_time)
                factory.count18 += 1
            elif factory.count18 == 3:
                yield env.timeout(model3_process18_time)
                factory.count18 = 1
            else:
                print("count18 error")
                raise SystemExit(0)
            yield factory.queue18.put(1)
            factory.pc18 += 1
            # x18.append(float(env.now))
            # y18.append(factory.queue18.level)

    def process19(env,factory):
        while True:
            yield factory.queue18.get(1)
            if factory.count19 == 1:
                yield env.timeout(model1_process19_time)
                factory.count19 += 1
            elif factory.count19 == 2:
                yield env.timeout(model2_process19_time)
                factory.count19 += 1
            elif factory.count19 == 3:
                yield env.timeout(model3_process19_time)
                factory.count19 = 1
            else:
                print("count19 error")
                raise SystemExit(0)
            yield factory.queue19.put(1)
            factory.pc19 += 1
            # x19.append(float(env.now))
            # y19.append(factory.queue19.level)


    def process20(env,factory):
        while True:
            yield factory.queue18.get(1)
            if factory.count20 == 1:
                yield env.timeout(model1_process20_time)
                factory.count20 += 1
            elif factory.count20 == 2:
                yield env.timeout(model2_process20_time)
                factory.count20 += 1
            elif factory.count20 == 3:
                yield env.timeout(model3_process20_time)
                factory.count20 = 1
            else:
                print("count20 error")
                raise SystemExit(0)
            yield factory.queue20.put(1)
            factory.pc20 += 1
            # x20.append(float(env.now))
            # y20.append(factory.queue20.level)

    def process21(env,factory):
        while True:
            yield factory.queue17.get(1)
            if factory.count21 == 1:
                yield env.timeout(model1_process21_time)
                factory.count21 += 1
            elif factory.count21 == 2:
                yield env.timeout(model2_process21_time)
                factory.count21 += 1
            elif factory.count21 == 3:
                yield env.timeout(model3_process21_time)
                factory.count21 = 1
            else:
                print("count21 error")
                raise SystemExit(0)
            yield factory.queue21.put(1)
            factory.pc21 += 1
            # x21.append(float(env.now))
            # y21.append(factory.queue21.level)

    def process22(env,factory):
        while True:
            yield factory.queue17.get(1)
            if factory.count22 == 1:
                yield env.timeout(model1_process22_time)
                factory.count22 += 1
            elif factory.count22 == 2:
                yield env.timeout(model2_process22_time)
                factory.count22 += 1
            elif factory.count22 == 3:
                yield env.timeout(model3_process22_time)
                factory.count22 = 1
            else:
                print("count22 error")
                raise SystemExit(0)
            yield factory.queue22.put(1)
            factory.pc22 += 1
            # x22.append(float(env.now))
            # y22.append(factory.queue22.level)

    def process23(env,factory):
        while True:
            yield factory.queue22.get(1)
            yield factory.queue21.get(1)
            if factory.count23 == 1:
                yield env.timeout(model1_process23_time)
                factory.count23 += 1
            elif factory.count23 == 2:
                yield env.timeout(model2_process23_time)
                factory.count23 += 1
            elif factory.count23 == 3:
                yield env.timeout(model3_process23_time)
                factory.count23 = 1
            else:
                print("count23 error")
                raise SystemExit(0)
            yield factory.queue23.put(1)
            factory.pc23 += 1
            # x23.append(float(env.now))
            # y23.append(factory.queue23.level)

    def process24(env,factory):
        while True:
            yield factory.queue21.get(1)
            if factory.count24 == 1:
                yield env.timeout(model1_process24_time)
                factory.count24 += 1
            elif factory.count24 == 2:
                yield env.timeout(model2_process24_time)
                factory.count24 += 1
            elif factory.count24 == 3:
                yield env.timeout(model3_process24_time)
                factory.count24 = 1
            else:
                print("count24 error")
                raise SystemExit(0)
            yield factory.queue24.put(1)
            factory.pc24 += 1
            # x24.append(float(env.now))
            # y24.append(factory.queue24.level)

    def process25(env,factory):
        while True:
            yield factory.queue19.get(1)
            yield factory.queue20.get(1)
            if factory.count25 == 1:
                yield env.timeout(model1_process25_time)
                factory.count25 += 1
            elif factory.count25 == 2:
                yield env.timeout(model2_process25_time)
                factory.count25 += 1
            elif factory.count25 == 3:
                yield env.timeout(model3_process25_time)
                factory.count25 = 1
            else:
                print("count25 error")
                raise SystemExit(0)
            yield factory.queue25.put(1)
            factory.pc25 += 1
            # x25.append(float(env.now))
            # y25.append(factory.queue25.level)

    def process26(env,factory):
        while True:
            yield factory.queue25.get(1)
            if factory.count26 == 1:
                yield env.timeout(model1_process26_time)
                factory.count26 += 1
            elif factory.count26 == 2:
                yield env.timeout(model2_process26_time)
                factory.count26 += 1
            elif factory.count26 == 3:
                yield env.timeout(model3_process26_time)
                factory.count26 = 1
            else:
                print("count26 error")
                raise SystemExit(0)
            yield factory.queue26.put(1)
            factory.pc26 += 1
            # x26.append(float(env.now))
            # y26.append(factory.queue26.level)

    def process27(env,factory):
        while True:
            yield factory.queue25.get(1)
            if factory.count27 == 1:
                yield env.timeout(model1_process27_time)
                factory.count27 += 1
            elif factory.count27 == 2:
                yield env.timeout(model2_process27_time)
                factory.count27 += 1
            elif factory.count27 == 3:
                yield env.timeout(model3_process27_time)
                factory.count27 = 1
            else:
                print("count27 error")
                raise SystemExit(0)
            yield factory.queue27.put(1)
            factory.pc27 += 1
            # x27.append(float(env.now))
            # y27.append(factory.queue27.level)

    def process28(env,factory):
        while True:
            yield factory.queue25.get(1)
            if factory.count28 == 1:
                yield env.timeout(model1_process28_time)
                factory.count28 += 1
            elif factory.count28 == 2:
                yield env.timeout(model2_process28_time)
                factory.count28 += 1
            elif factory.count28 == 3:
                yield env.timeout(model3_process28_time)
                factory.count2 = 1
            else:
                print("count28 error")
                raise SystemExit(0)
            yield factory.queue28.put(1)
            factory.pc28 += 1
            # x28.append(float(env.now))
            # y28.append(factory.queue28.level)


    def process29(env,factory):
        while True:
            yield factory.queue28.get(1)
            yield factory.queue24.get(1)
            if factory.count29 == 1:
                yield env.timeout(model1_process29_time)
                factory.count29 += 1
            elif factory.count29 == 2:
                yield env.timeout(model2_process29_time)
                factory.count29 += 1
            elif factory.count29 == 3:
                yield env.timeout(model3_process29_time)
                factory.count29 = 1
            else:
                print("count29 error")
                raise SystemExit(0)
            yield factory.queue29.put(1)
            factory.pc29 += 1
            # x29.append(float(env.now))
            # y29.append(factory.queue29.level)

    def process30(env,factory):
        while True:
            yield factory.queue23.get(1)
            if factory.count30 == 1:
                yield env.timeout(model1_process30_time)
                factory.count30 += 1
            elif factory.count30 == 2:
                yield env.timeout(model2_process30_time)
                factory.count30 += 1
            elif factory.count30 == 3:
                yield env.timeout(model3_process30_time)
                factory.count30 = 1
            else:
                print("count30 error")
                raise SystemExit(0)
            yield factory.queue30.put(1)
            factory.pc30 += 1
            # x30.append(float(env.now))
            # y30.append(factory.queue30.level)


    def process31(env,factory):
        while True:
            yield factory.queue30.get(1)
            if factory.count31 == 1:
                yield env.timeout(model1_process31_time)
                factory.count31 += 1
            elif factory.count31 == 2:
                yield env.timeout(model2_process31_time)
                factory.count31 += 1
            elif factory.count31 == 3:
                yield env.timeout(model3_process31_time)
                factory.count31 = 1
            else:
                print("count31 error")
                raise SystemExit(0)
            yield factory.queue31.put(1)
            factory.pc31 += 1
            # x31.append(float(env.now))
            # y31.append(factory.queue31.level)


    def process32(env,factory):
        while True:
            yield factory.queue27.get(1)
            if factory.count32 == 1:
                yield env.timeout(model1_process32_time)
                factory.count32 += 1
            elif factory.count32 == 2:
                yield env.timeout(model2_process32_time)
                factory.count32 += 1
            elif factory.count32 == 3:
                yield env.timeout(model3_process32_time)
                factory.count32 = 1
            else:
                print("count32 error")
                raise SystemExit(0)
            yield factory.queue32.put(1)
            factory.pc32 += 1
            # x32.append(float(env.now))
            # y32.append(factory.queue32.level)

    def process33(env,factory):
        while True:
            yield factory.queue26.get(1)
            if factory.count33 == 1:
                yield env.timeout(model1_process33_time)
                factory.count33 += 1
            elif factory.count33 == 2:
                yield env.timeout(model2_process33_time)
                factory.count33 += 1
            elif factory.count33 == 3:
                yield env.timeout(model3_process33_time)
                factory.count33 = 1
            else:
                print("count33 error")
                raise SystemExit(0)
            yield factory.queue33.put(1)
            factory.pc33 += 1
            # x33.append(float(env.now))
            # y33.append(factory.queue33.level)

    def process34(env,factory):
        while True:
            yield factory.queue32.get(1)
            yield factory.queue29.get(1)
            if factory.count34 == 1:
                yield env.timeout(model1_process34_time)
                factory.count34 += 1
            elif factory.count34 == 2:
                yield env.timeout(model2_process34_time)
                factory.count34 += 1
            elif factory.count34 == 3:
                yield env.timeout(model3_process34_time)
                factory.count34 = 1
            else:
                print("count34 error")
                raise SystemExit(0)
            yield factory.queue34.put(1)
            factory.pc34 += 1
            # x34.append(float(env.now))
            # y34.append(factory.queue34.level)

    def process35(env,factory):
        while True:
            yield factory.queue31.get(1)
            if factory.count35 == 1:
                yield env.timeout(model1_process35_time)
                factory.count35 += 1
            elif factory.count35 == 2:
                yield env.timeout(model2_process35_time)
                factory.count35 += 1
            elif factory.count35 == 3:
                yield env.timeout(model3_process35_time)
                factory.count35 = 1
            else:
                print("count35 error")
                raise SystemExit(0)
            yield factory.queue35.put(1)
            factory.pc35 += 1
            # x35.append(float(env.now))
            # y35.append(factory.queue35.level)

    def process36(env,factory):
        while True:
            yield factory.queue35.get(1)
            yield factory.queue34.get(1)
            if factory.count36 == 1:
                yield env.timeout(model1_process36_time)
                factory.count36 += 1
            elif factory.count36 == 2:
                yield env.timeout(model2_process36_time)
                factory.count36 += 1
            elif factory.count36 == 3:
                yield env.timeout(model3_process36_time)
                factory.count36 = 1
            else:
                print("count36 error")
                raise SystemExit(0)
            yield factory.queue36.put(1)
            factory.pc36 += 1
            # x36.append(float(env.now))
            # y36.append(factory.queue36.level)

    def process37(env,factory):
        while True:
            yield factory.queue32.get(1)
            if factory.count37 == 1:
                yield env.timeout(model1_process37_time)
                factory.count37 += 1
            elif factory.count37 == 2:
                yield env.timeout(model2_process37_time)
                factory.count37 += 1
            elif factory.count37 == 3:
                yield env.timeout(model3_process37_time)
                factory.count37 = 1
            else:
                print("count37 error")
                raise SystemExit(0)
            yield factory.queue37.put(1)
            factory.pc37 += 1
            # x37.append(float(env.now))
            # y37.append(factory.queue37.level)

    def process38(env,factory):
        while True:
            yield factory.queue33.get(1)
            if factory.count38 == 1:
                yield env.timeout(model1_process38_time)
                factory.count38 += 1
            elif factory.count38 == 2:
                yield env.timeout(model2_process38_time)
                factory.count38 += 1
            elif factory.count38 == 3:
                yield env.timeout(model3_process38_time)
                factory.count38 = 1
            else:
                print("count38 error")
                raise SystemExit(0)
            yield factory.queue38.put(1)
            factory.pc38 += 1
            # x38.append(float(env.now))
            # y38.append(factory.queue38.level)

    def process39(env,factory):
        while True:
            yield factory.queue38.get(1)
            if factory.count39 == 1:
                yield env.timeout(model1_process39_time)
                factory.count39 += 1
            elif factory.count39 == 2:
                yield env.timeout(model2_process39_time)
                factory.count39 += 1
            elif factory.count39 == 3:
                yield env.timeout(model3_process39_time)
                factory.count39 = 1
            else:
                print("count39 error")
                raise SystemExit(0)
            yield factory.queue39.put(1)
            factory.pc39 += 1
            # x39.append(float(env.now))
            # y39.append(factory.queue39.level)

    def process40(env,factory):
        while True:
            yield factory.queue36.get(1)
            if factory.count40 == 1:
                yield env.timeout(model1_process40_time)
                factory.count40 += 1
            elif factory.count40 == 2:
                yield env.timeout(model2_process40_time)
                factory.count40 += 1
            elif factory.count40 == 3:
                yield env.timeout(model3_process40_time)
                factory.count40 = 1
            else:
                print("count40 error")
                raise SystemExit(0)
            yield factory.queue40.put(1)
            factory.pc40 += 1
            # x40.append(float(env.now))
            # y40.append(factory.queue40.level)



    def process41(env,factory):
        while True:
            yield factory.queue37.get(1)
            yield factory.queue39.get(1)
            yield factory.queue40.get(1)
            if factory.count41 == 1:
                factory.count41 += 1
            elif factory.count41 == 2:
                factory.count41 += 1
            elif factory.count41 == 3:
                factory.count41 = 1
            else:
                print("count40 error")
                raise SystemExit(0)
            yield factory.queue41.put(20)
            factory.pc41 += 1
            # print(((env.now), 'time'))
            # x41.append(float(env.now))
            # y41.append(factory.dispatch.level)

    def Bprocess1(env,factory):
        while True:
            yield factory.queue41.get(1)
            if factory.Bcount1 == 1:
                yield env.timeout(model1_process1_time)
                factory.Bcount1 += 1
            elif factory.Bcount1 == 2:
                yield env.timeout(model2_process1_time)
                factory.Bcount1 += 1
            elif factory.Bcount1 == 3:
                yield env.timeout(model3_process1_time)
                factory.Bcount1 = 1
            else:
                print("count1 error")
                raise SystemExit(0)
            yield factory.Bqueue1.put(1)
            # factory.pc1 += 1
            # x1.append(float(env.now))
            # y1.append(factory.Bqueue1.level)

    def Bprocess2(env,factory):
        while True:
            yield factory.queue41.get(1)
            if factory.Bcount2 == 1:
                yield env.timeout(model1_process2_time)
                factory.Bcount2 += 1
            elif factory.Bcount2 == 2:
                yield env.timeout(model2_process2_time)
                factory.Bcount2 += 1
            elif factory.Bcount2 == 3:
                yield env.timeout(model3_process2_time)
                factory.Bcount2 = 1
            else:
                print("count2 error")
                raise SystemExit(0)
            yield factory.Bqueue2.put(1)
            # factory.pc2 += 1
            # x2.append(float(env.now))
            # y2.append(factory.Bqueue2.level)

    def Bprocess3(env,factory):
        while True:
            yield factory.Bqueue1.get(1)
            yield factory.Bqueue2.get(1)
            if factory.Bcount3 == 1:
                yield env.timeout(model1_process3_time)
                factory.Bcount3 += 1
            elif factory.Bcount3 == 2:
                yield env.timeout(model2_process3_time)
                factory.Bcount3 += 1
            elif factory.Bcount3 == 3:
                yield env.timeout(model3_process3_time)
                factory.Bcount3 = 1
            else:
                print("count3 error")
                raise SystemExit(0)
            yield factory.Bqueue3.put(1)
            # factory.pc3 += 1
            # x3.append(float(env.now))
            # y3.append(factory.Bqueue3.level)

    def Bprocess4(env,factory):
        while True:
            yield factory.Bqueue1.get(1)
            if factory.Bcount4 == 1:
                yield env.timeout(model1_process4_time)
                factory.Bcount4 += 1
            elif factory.Bcount4 == 2:
                yield env.timeout(model2_process4_time)
                factory.Bcount4 += 1
            elif factory.Bcount4 == 3:
                yield env.timeout(model3_process4_time)
                factory.Bcount4 = 1
            else:
                print("count4 error")
                raise SystemExit(0)
            yield factory.Bqueue4.put(1)
            # factory.pc4 += 1
            # x4.append(float(env.now))
            # y4.append(factory.Bqueue4.level)

    def Bprocess5(env,factory):
        while True:
            yield factory.Bqueue4.get(1)
            if factory.Bcount5 == 1:
                yield env.timeout(model1_process5_time)
                factory.Bcount5 += 1
            elif factory.Bcount5 == 2:
                yield env.timeout(model2_process5_time)
                factory.Bcount5 += 1
            elif factory.Bcount5 == 3:
                yield env.timeout(model3_process5_time)
                factory.Bcount5 = 1
            else:
                print("count5 error")
                raise SystemExit(0)
            yield factory.Bqueue5.put(1)
            # factory.pc5 += 1
            # x5.append(float(env.now))
            # y5.append(factory.Bqueue5.level)

    def Bprocess6(env,factory):
        while True:
            yield factory.Bqueue3.get(1)
            if factory.Bcount6 == 1:
                yield env.timeout(model1_process6_time)
                factory.Bcount6 += 1
            elif factory.Bcount6 == 2:
                yield env.timeout(model2_process6_time)
                factory.Bcount6 += 1
            elif factory.Bcount6 == 3:
                yield env.timeout(model3_process6_time)
                factory.Bcount6 = 1
            else:
                print("count6 error")
                raise SystemExit(0)
            yield factory.Bqueue6.put(1)
            # factory.pc6 += 1
            # x6.append(float(env.now))
            # y6.append(factory.Bqueue6.level)

    def Bprocess7(env,factory):
        while True:
            yield factory.Bqueue2.get(1)
            if factory.Bcount7 == 1:
                yield env.timeout(model1_process7_time)
                factory.Bcount7 += 1
            elif factory.Bcount7 == 2:
                yield env.timeout(model2_process7_time)
                factory.Bcount7 += 1
            elif factory.Bcount7 == 3:
                yield env.timeout(model3_process7_time)
                factory.Bcount7 = 1
            else:
                print("count7 error")
                raise SystemExit(0)
            yield factory.Bqueue7.put(1)
            # factory.pc7 += 1
            # x7.append(float(env.now))
            # y7.append(factory.Bqueue7.level)

    def Bprocess8(env,factory):
        while True:
            yield factory.Bqueue7.get(1)
            if factory.Bcount8 == 1:
                yield env.timeout(model1_process8_time)
                factory.Bcount8 += 1
            elif factory.Bcount8 == 2:
                yield env.timeout(model2_process8_time)
                factory.Bcount8+= 1
            elif factory.Bcount8 == 3:
                yield env.timeout(model3_process8_time)
                factory.Bcount8 = 1
            else:
                print("count8 error")
                raise SystemExit(0)
            yield factory.Bqueue8.put(1)
            # factory.pc8 += 1
            # x8.append(float(env.now))
            # y8.append(factory.Bqueue8.level)

    def Bprocess9(env,factory):
        while True:
            yield factory.Bqueue7.get(1)
            if factory.Bcount9 == 1:
                yield env.timeout(model1_process9_time)
                factory.Bcount9 += 1
            elif factory.Bcount9 == 2:
                yield env.timeout(model2_process9_time)
                factory.Bcount9 += 1
            elif factory.Bcount9 == 3:
                yield env.timeout(model3_process9_time)
                factory.Bcount9 = 1
            else:
                print("count9 error")
                raise SystemExit(0)
            yield factory.Bqueue9.put(1)
            # factory.pc9 += 1
            # x9.append(float(env.now))
            # y9.append(factory.Bqueue9.level)

    def Bprocess10(env,factory):
        while True:
            yield factory.Bqueue8.get(1)
            yield factory.Bqueue9.get(1)
            if factory.Bcount10 == 1:
                yield env.timeout(model1_process10_time)
                factory.Bcount10 += 1
            elif factory.Bcount10 == 2:
                yield env.timeout(model2_process10_time)
                factory.Bcount10 += 1
            elif factory.Bcount10 == 3:
                yield env.timeout(model3_process10_time)
                factory.Bcount10 = 1
            else:
                print("count10 error")
                raise SystemExit(0)
            yield factory.Bqueue10.put(1)
            # factory.pc10 += 1
            # x10.append(float(env.now))
            # y10.append(factory.Bqueue10.level)

    def Bprocess11(env,factory):
        while True:
            yield factory.Bqueue6.get(1)
            if factory.Bcount11 == 1:
                yield env.timeout(model1_process11_time)
                factory.Bcount11 += 1
            elif factory.Bcount11 == 2:
                yield env.timeout(model2_process11_time)
                factory.Bcount11 += 1
            elif factory.Bcount11 == 3:
                yield env.timeout(model3_process11_time)
                factory.Bcount11 = 1
            else:
                print("count11 error")
                raise SystemExit(0)
            yield factory.Bqueue11.put(1)
            # factory.pc11 += 1
            # x11.append(float(env.now))
            # y11.append(factory.Bqueue11.level)

    def Bprocess12(env,factory):
        while True:
            yield factory.Bqueue5.get(1)
            if factory.Bcount12 == 1:
                yield env.timeout(model1_process12_time)
                factory.Bcount12 += 1
            elif factory.Bcount12 == 2:
                yield env.timeout(model2_process12_time)
                factory.Bcount12 += 1
            elif factory.Bcount12 == 3:
                yield env.timeout(model3_process12_time)
                factory.Bcount12 = 1
            else:
                print("count12 error")
                raise SystemExit(0)
            yield factory.Bqueue12.put(1)
            # factory.pc12 += 1
            # x12.append(float(env.now))
            # y12.append(factory.Bqueue12.level)

    def Bprocess13(env,factory):
        while True:
            yield factory.Bqueue5.get(1)
            if factory.Bcount13 == 1:
                yield env.timeout(model1_process13_time)
                factory.Bcount13 += 1
            elif factory.Bcount13 == 2:
                yield env.timeout(model2_process13_time)
                factory.Bcount13 += 1
            elif factory.Bcount13 == 3:
                yield env.timeout(model3_process13_time)
                factory.Bcount13 = 1
            else:
                print("count13 error")
                raise SystemExit(0)
            yield factory.Bqueue13.put(1)
            # factory.pc13 += 1
            # x13.append(float(env.now))
            # y13.append(factory.Bqueue13.level)


    def Bprocess14(env,factory):
        while True:
            yield factory.Bqueue11.get(1)
            yield factory.Bqueue13.get(1)
            if factory.Bcount14 == 1:
                yield env.timeout(model1_process14_time)
                factory.Bcount14 += 1
            elif factory.Bcount14 == 2:
                yield env.timeout(model2_process14_time)
                factory.Bcount14 += 1
            elif factory.Bcount14 == 3:
                yield env.timeout(model3_process14_time)
                factory.Bcount14 = 1
            else:
                print("count14 error")
                raise SystemExit(0)
            yield factory.Bqueue14.put(1)
            # factory.pc14 += 1
            # x14.append(float(env.now))
            # y14.append(factory.Bqueue14.level)

    def Bprocess15(env,factory):
        while True:
            yield factory.Bqueue12.get(1)
            if factory.Bcount15 == 1:
                yield env.timeout(model1_process15_time)
                factory.Bcount15 += 1
            elif factory.Bcount15 == 2:
                yield env.timeout(model2_process15_time)
                factory.Bcount15 += 1
            elif factory.Bcount15 == 3:
                yield env.timeout(model3_process15_time)
                factory.Bcount15 = 1
            else:
                print("count15 error")
                raise SystemExit(0)
            yield factory.Bqueue15.put(1)
            # factory.pc15 += 1
            # x15.append(float(env.now))
            # y15.append(factory.Bqueue15.level)


    def Bprocess16(env,factory):
        while True:
            yield factory.Bqueue10.get(1)
            if factory.Bcount16 == 1:
                yield env.timeout(model1_process16_time)
                factory.Bcount16 += 1
            elif factory.Bcount16 == 2:
                yield env.timeout(model2_process16_time)
                factory.Bcount16 += 1
            elif factory.Bcount16 == 3:
                yield env.timeout(model3_process16_time)
                factory.Bcount16 = 1
            else:
                print("count16 error")
                raise SystemExit(0)
            yield factory.Bqueue16.put(1)
            # factory.pc16 += 1
            # x16.append(float(env.now))
            # y16.append(factory.Bqueue16.level)

    def Bprocess17(env,factory):
        while True:
            yield factory.Bqueue15.get(1)
            yield factory.Bqueue14.get(1)
            if factory.Bcount17 == 1:
                yield env.timeout(model1_process17_time)
                factory.Bcount17 += 1
            elif factory.Bcount17 == 2:
                yield env.timeout(model2_process17_time)
                factory.Bcount17 += 1
            elif factory.Bcount17 == 3:
                yield env.timeout(model3_process17_time)
                factory.Bcount17 = 1
            else:
                print("count17 error")
                raise SystemExit(0)
            yield factory.Bqueue17.put(1)
            # factory.pc17 += 1
            # x17.append(float(env.now))
            # y17.append(factory.Bqueue17.level)

    def Bprocess18(env,factory):
        while True:
            yield factory.Bqueue16.get(1)
            if factory.Bcount18 == 1:
                yield env.timeout(model1_process18_time)
                factory.Bcount18 += 1
            elif factory.Bcount18 == 2:
                yield env.timeout(model2_process18_time)
                factory.Bcount18 += 1
            elif factory.Bcount18 == 3:
                yield env.timeout(model3_process18_time)
                factory.Bcount18 = 1
            else:
                print("count18 error")
                raise SystemExit(0)
            yield factory.Bqueue18.put(1)
            # factory.pc18 += 1
            # x18.append(float(env.now))
            # y18.append(factory.Bqueue18.level)

    def Bprocess19(env,factory):
        while True:
            yield factory.Bqueue18.get(1)
            if factory.Bcount19 == 1:
                yield env.timeout(model1_process19_time)
                factory.Bcount19 += 1
            elif factory.Bcount19 == 2:
                yield env.timeout(model2_process19_time)
                factory.Bcount19 += 1
            elif factory.Bcount19 == 3:
                yield env.timeout(model3_process19_time)
                factory.Bcount19 = 1
            else:
                print("count19 error")
                raise SystemExit(0)
            yield factory.Bqueue19.put(1)
            # factory.pc19 += 1
            # x19.append(float(env.now))
            # y19.append(factory.Bqueue19.level)


    def Bprocess20(env,factory):
        while True:
            yield factory.Bqueue18.get(1)
            if factory.Bcount20 == 1:
                yield env.timeout(model1_process20_time)
                factory.Bcount20 += 1
            elif factory.Bcount20 == 2:
                yield env.timeout(model2_process20_time)
                factory.Bcount20 += 1
            elif factory.Bcount20 == 3:
                yield env.timeout(model3_process20_time)
                factory.Bcount20 = 1
            else:
                print("count20 error")
                raise SystemExit(0)
            yield factory.Bqueue20.put(1)
            # factory.pc20 += 1
            # x20.append(float(env.now))
            # y20.append(factory.Bqueue20.level)

    def Bprocess21(env,factory):
        while True:
            yield factory.Bqueue17.get(1)
            if factory.Bcount21 == 1:
                yield env.timeout(model1_process21_time)
                factory.Bcount21 += 1
            elif factory.Bcount21 == 2:
                yield env.timeout(model2_process21_time)
                factory.Bcount21 += 1
            elif factory.Bcount21 == 3:
                yield env.timeout(model3_process21_time)
                factory.Bcount21 = 1
            else:
                print("Bcount21 error")
                raise SystemExit(0)
            yield factory.Bqueue21.put(1)
            # factory.pc21 += 1
            # x21.append(float(env.now))
            # y21.append(factory.Bqueue21.level)

    def Bprocess22(env,factory):
        while True:
            yield factory.Bqueue17.get(1)
            if factory.Bcount22 == 1:
                yield env.timeout(model1_process22_time)
                factory.Bcount22 += 1
            elif factory.Bcount22 == 2:
                yield env.timeout(model2_process22_time)
                factory.Bcount22 += 1
            elif factory.Bcount22 == 3:
                yield env.timeout(model3_process22_time)
                factory.Bcount22 = 1
            else:
                print("Bcount22 error")
                raise SystemExit(0)
            yield factory.Bqueue22.put(1)
            # factory.pc22 += 1
            # x22.append(float(env.now))
            # y22.append(factory.Bqueue22.level)

    def Bprocess23(env,factory):
        while True:
            yield factory.Bqueue22.get(1)
            yield factory.Bqueue21.get(1)
            if factory.Bcount23 == 1:
                yield env.timeout(model1_process23_time)
                factory.Bcount23 += 1
            elif factory.Bcount23 == 2:
                yield env.timeout(model2_process23_time)
                factory.Bcount23 += 1
            elif factory.Bcount23 == 3:
                yield env.timeout(model3_process23_time)
                factory.Bcount23 = 1
            else:
                print("count23 error")
                raise SystemExit(0)
            yield factory.Bqueue23.put(1)
            # factory.pc23 += 1
            # x23.append(float(env.now))
            # y23.append(factory.Bqueue23.level)

    def Bprocess24(env,factory):
        while True:
            yield factory.Bqueue21.get(1)
            if factory.Bcount24 == 1:
                yield env.timeout(model1_process24_time)
                factory.Bcount24 += 1
            elif factory.Bcount24 == 2:
                yield env.timeout(model2_process24_time)
                factory.Bcount24 += 1
            elif factory.Bcount24 == 3:
                yield env.timeout(model3_process24_time)
                factory.Bcount24 = 1
            else:
                print("Bcount24 error")
                raise SystemExit(0)
            yield factory.Bqueue24.put(1)
            factory.pc24 += 1
            x24.append(float(env.now))
            y24.append(factory.Bqueue24.level)

    def Bprocess25(env,factory):
        while True:
            yield factory.Bqueue19.get(1)
            yield factory.Bqueue20.get(1)
            if factory.Bcount25 == 1:
                yield env.timeout(model1_process25_time)
                factory.Bcount25 += 1
            elif factory.Bcount25 == 2:
                yield env.timeout(model2_process25_time)
                factory.Bcount25 += 1
            elif factory.Bcount25 == 3:
                yield env.timeout(model3_process25_time)
                factory.Bcount25 = 1
            else:
                print("Bcount25 error")
                raise SystemExit(0)
            yield factory.Bqueue25.put(1)
            # factory.pc25 += 1
            # x25.append(float(env.now))
            # y25.append(factory.Bqueue25.level)

    def Bprocess26(env,factory):
        while True:
            yield factory.Bqueue25.get(1)
            if factory.Bcount26 == 1:
                yield env.timeout(model1_process26_time)
                factory.Bcount26 += 1
            elif factory.Bcount26 == 2:
                yield env.timeout(model2_process26_time)
                factory.Bcount26 += 1
            elif factory.Bcount26 == 3:
                yield env.timeout(model3_process26_time)
                factory.Bcount26 = 1
            else:
                print("Bcount26 error")
                raise SystemExit(0)
            yield factory.Bqueue26.put(1)
            # factory.pc26 += 1
            # x26.append(float(env.now))
            # y26.append(factory.Bqueue26.level)

    def Bprocess27(env,factory):
        while True:
            yield factory.Bqueue25.get(1)
            if factory.Bcount27 == 1:
                yield env.timeout(model1_process27_time)
                factory.Bcount27 += 1
            elif factory.Bcount27 == 2:
                yield env.timeout(model2_process27_time)
                factory.Bcount27 += 1
            elif factory.Bcount27 == 3:
                yield env.timeout(model3_process27_time)
                factory.Bcount27 = 1
            else:
                print("Bcount27 error")
                raise SystemExit(0)
            yield factory.Bqueue27.put(1)
            # factory.pc27 += 1
            # x27.append(float(env.now))
            # y27.append(factory.Bqueue27.level)

    def Bprocess28(env,factory):
        while True:
            yield factory.Bqueue25.get(1)
            if factory.Bcount28 == 1:
                yield env.timeout(model1_process28_time)
                factory.Bcount28 += 1
            elif factory.Bcount28 == 2:
                yield env.timeout(model2_process28_time)
                factory.Bcount28 += 1
            elif factory.Bcount28 == 3:
                yield env.timeout(model3_process28_time)
                factory.Bcount2 = 1
            else:
                print("Bcount28 error")
                raise SystemExit(0)
            yield factory.Bqueue28.put(1)
            # factory.pc28 += 1
            # x28.append(float(env.now))
            # y28.append(factory.Bqueue28.level)


    def Bprocess29(env,factory):
        while True:
            yield factory.Bqueue28.get(1)
            yield factory.Bqueue24.get(1)
            if factory.Bcount29 == 1:
                yield env.timeout(model1_process29_time)
                factory.Bcount29 += 1
            elif factory.Bcount29 == 2:
                yield env.timeout(model2_process29_time)
                factory.Bcount29 += 1
            elif factory.Bcount29 == 3:
                yield env.timeout(model3_process29_time)
                factory.Bcount29 = 1
            else:
                print("Bcount29 error")
                raise SystemExit(0)
            yield factory.Bqueue29.put(1)
            # factory.pc29 += 1
            # x29.append(float(env.now))
            # y29.append(factory.Bqueue29.level)

    def Bprocess30(env,factory):
        while True:
            yield factory.Bqueue23.get(1)
            if factory.Bcount30 == 1:
                yield env.timeout(model1_process30_time)
                factory.Bcount30 += 1
            elif factory.Bcount30 == 2:
                yield env.timeout(model2_process30_time)
                factory.Bcount30 += 1
            elif factory.Bcount30 == 3:
                yield env.timeout(model3_process30_time)
                factory.Bcount30 = 1
            else:
                print("Bcount30 error")
                raise SystemExit(0)
            yield factory.Bqueue30.put(1)
            # factory.pc30 += 1
            # x30.append(float(env.now))
            # y30.append(factory.Bqueue30.level)


    def Bprocess31(env,factory):
        while True:
            yield factory.Bqueue30.get(1)
            if factory.Bcount31 == 1:
                yield env.timeout(model1_process31_time)
                factory.Bcount31 += 1
            elif factory.Bcount31 == 2:
                yield env.timeout(model2_process31_time)
                factory.Bcount31 += 1
            elif factory.Bcount31 == 3:
                yield env.timeout(model3_process31_time)
                factory.Bcount31 = 1
            else:
                print("Bcount31 error")
                raise SystemExit(0)
            yield factory.Bqueue31.put(1)
            # factory.pc31 += 1
            # x31.append(float(env.now))
            # y31.append(factory.Bqueue31.level)


    def Bprocess32(env,factory):
        while True:
            yield factory.Bqueue27.get(1)
            if factory.Bcount32 == 1:
                yield env.timeout(model1_process32_time)
                factory.Bcount32 += 1
            elif factory.Bcount32 == 2:
                yield env.timeout(model2_process32_time)
                factory.Bcount32 += 1
            elif factory.Bcount32 == 3:
                yield env.timeout(model3_process32_time)
                factory.Bcount32 = 1
            else:
                print("Bcount32 error")
                raise SystemExit(0)
            yield factory.Bqueue32.put(1)
            # factory.pc32 += 1
            # x32.append(float(env.now))
            # y32.append(factory.Bqueue32.level)

    def Bprocess33(env,factory):
        while True:
            yield factory.Bqueue26.get(1)
            if factory.Bcount33 == 1:
                yield env.timeout(model1_process33_time)
                factory.Bcount33 += 1
            elif factory.Bcount33 == 2:
                yield env.timeout(model2_process33_time)
                factory.Bcount33 += 1
            elif factory.Bcount33 == 3:
                yield env.timeout(model3_process33_time)
                factory.Bcount33 = 1
            else:
                print("Bcount33 error")
                raise SystemExit(0)
            yield factory.Bqueue33.put(1)
            # factory.pc33 += 1
            # x33.append(float(env.now))
            # y33.append(factory.Bqueue33.level)

    def Bprocess34(env,factory):
        while True:
            yield factory.Bqueue32.get(1)
            yield factory.Bqueue29.get(1)
            if factory.Bcount34 == 1:
                yield env.timeout(model1_process34_time)
                factory.Bcount34 += 1
            elif factory.Bcount34 == 2:
                yield env.timeout(model2_process34_time)
                factory.Bcount34 += 1
            elif factory.Bcount34 == 3:
                yield env.timeout(model3_process34_time)
                factory.Bcount34 = 1
            else:
                print("Bcount34 error")
                raise SystemExit(0)
            yield factory.Bqueue34.put(1)
            # factory.pc34 += 1
            # x34.append(float(env.now))
            # y34.append(factory.Bqueue34.level)

    def Bprocess35(env,factory):
        while True:
            yield factory.Bqueue31.get(1)
            if factory.Bcount35 == 1:
                yield env.timeout(model1_process35_time)
                factory.Bcount35 += 1
            elif factory.Bcount35 == 2:
                yield env.timeout(model2_process35_time)
                factory.Bcount35 += 1
            elif factory.Bcount35 == 3:
                yield env.timeout(model3_process35_time)
                factory.Bcount35 = 1
            else:
                print("Bcount35 error")
                raise SystemExit(0)
            yield factory.Bqueue35.put(1)
            # factory.pc35 += 1
            # x35.append(float(env.now))
            # y35.append(factory.Bqueue35.level)

    def Bprocess36(env,factory):
        while True:
            yield factory.Bqueue35.get(1)
            yield factory.Bqueue34.get(1)
            if factory.Bcount36 == 1:
                yield env.timeout(model1_process36_time)
                factory.Bcount36 += 1
            elif factory.Bcount36 == 2:
                yield env.timeout(model2_process36_time)
                factory.Bcount36 += 1
            elif factory.Bcount36 == 3:
                yield env.timeout(model3_process36_time)
                factory.Bcount36 = 1
            else:
                print("Bcount36 error")
                raise SystemExit(0)
            yield factory.Bqueue36.put(1)
            # factory.pc36 += 1
            # x36.append(float(env.now))
            # y36.append(factory.Bqueue36.level)

    def Bprocess37(env,factory):
        while True:
            yield factory.Bqueue32.get(1)
            if factory.Bcount37 == 1:
                yield env.timeout(model1_process37_time)
                factory.Bcount37 += 1
            elif factory.Bcount37 == 2:
                yield env.timeout(model2_process37_time)
                factory.Bcount37 += 1
            elif factory.Bcount37 == 3:
                yield env.timeout(model3_process37_time)
                factory.Bcount37 = 1
            else:
                print("Bcount37 error")
                raise SystemExit(0)
            yield factory.Bqueue37.put(1)
            # factory.pc37 += 1
            # x37.append(float(env.now))
            # y37.append(factory.Bqueue37.level)

    def Bprocess38(env,factory):
        while True:
            yield factory.Bqueue33.get(1)
            if factory.Bcount38 == 1:
                yield env.timeout(model1_process38_time)
                factory.Bcount38 += 1
            elif factory.Bcount38 == 2:
                yield env.timeout(model2_process38_time)
                factory.Bcount38 += 1
            elif factory.Bcount38 == 3:
                yield env.timeout(model3_process38_time)
                factory.Bcount38 = 1
            else:
                print("Bcount38 error")
                raise SystemExit(0)
            yield factory.Bqueue38.put(1)
            # factory.pc38 += 1
            # x38.append(float(env.now))
            # y38.append(factory.Bqueue38.level)

    def Bprocess39(env,factory):
        while True:
            yield factory.Bqueue38.get(1)
            if factory.Bcount39 == 1:
                yield env.timeout(model1_process39_time)
                factory.Bcount39 += 1
            elif factory.Bcount39 == 2:
                yield env.timeout(model2_process39_time)
                factory.Bcount39 += 1
            elif factory.Bcount39 == 3:
                yield env.timeout(model3_process39_time)
                factory.Bcount39 = 1
            else:
                print("Bcount39 error")
                raise SystemExit(0)
            yield factory.Bqueue39.put(1)
            # factory.pc39 += 1
            # x39.append(float(env.now))
            # y39.append(factory.Bqueue39.level)

    def Bprocess40(env,factory):
        while True:
            yield factory.Bqueue36.get(1)
            if factory.Bcount40 == 1:
                yield env.timeout(model1_process40_time)
                factory.Bcount40 += 1
            elif factory.Bcount40 == 2:
                yield env.timeout(model2_process40_time)
                factory.Bcount40 += 1
            elif factory.Bcount40 == 3:
                yield env.timeout(model3_process40_time)
                factory.Bcount40 = 1
            else:
                print("Bcount40 error")
                raise SystemExit(0)
            yield factory.Bqueue40.put(1)
            # factory.pc40 += 1
            # x40.append(float(env.now))
            # y40.append(factory.Bqueue40.level)



    def Bprocess41(env,factory):
        while True:
            yield factory.Bqueue37.get(1)
            yield factory.Bqueue39.get(1)
            yield factory.Bqueue40.get(1)
            if factory.Bcount41 == 1:
                factory.Bcount41 += 1
            elif factory.Bcount41 == 2:
                factory.Bcount41 += 1
            elif factory.Bcount41 == 3:
                factory.Bcount41 = 1
            else:
                print("Bcount40 error")
                raise SystemExit(0)
            yield factory.Bqueue41.put(20)
            # factory.pc41 += 1
            # x41.append(float(env.now))
            # y41.append(factory.Bqueue41.level)

    def Cprocess1(env,factory):
        while True:
            yield factory.Bqueue41.get(1)
            if factory.Ccount1 == 1:
                yield env.timeout(model1_process1_time)
                factory.Ccount1 += 1
            elif factory.Ccount1 == 2:
                yield env.timeout(model2_process1_time)
                factory.Ccount1 += 1
            elif factory.Ccount1 == 3:
                yield env.timeout(model3_process1_time)
                factory.Ccount1 = 1
            else:
                print("Ccount1 error")
                raise SystemExit(0)
            yield factory.Cqueue1.put(1)
            factory.pc1 += 1
            x1.append(float(env.now))
            y1.append(factory.Cqueue1.level)

    def Cprocess2(env,factory):
        while True:
            yield factory.Bqueue41.get(1)
            if factory.Ccount2 == 1:
                yield env.timeout(model1_process2_time)
                factory.Ccount2 += 1
            elif factory.Ccount2 == 2:
                yield env.timeout(model2_process2_time)
                factory.Ccount2 += 1
            elif factory.Ccount2 == 3:
                yield env.timeout(model3_process2_time)
                factory.Ccount2 = 1
            else:
                print("Ccount2 error")
                raise SystemExit(0)
            yield factory.Cqueue2.put(1)
            factory.pc2 += 1
            x2.append(float(env.now))
            y2.append(factory.Cqueue2.level)

    def Cprocess3(env,factory):
        while True:
            yield factory.Cqueue1.get(1)
            yield factory.Cqueue2.get(1)
            if factory.Ccount3 == 1:
                yield env.timeout(model1_process3_time)
                factory.Ccount3 += 1
            elif factory.Ccount3 == 2:
                yield env.timeout(model2_process3_time)
                factory.Ccount3 += 1
            elif factory.Ccount3 == 3:
                yield env.timeout(model3_process3_time)
                factory.Ccount3 = 1
            else:
                print("Ccount3 error")
                raise SystemExit(0)
            yield factory.Cqueue3.put(1)
            factory.pc3 += 1
            x3.append(float(env.now))
            y3.append(factory.Cqueue3.level)

    def Cprocess4(env,factory):
        while True:
            yield factory.Cqueue1.get(1)
            if factory.Ccount4 == 1:
                yield env.timeout(model1_process4_time)
                factory.Ccount4 += 1
            elif factory.Ccount4 == 2:
                yield env.timeout(model2_process4_time)
                factory.Ccount4 += 1
            elif factory.Ccount4 == 3:
                yield env.timeout(model3_process4_time)
                factory.Ccount4 = 1
            else:
                print("Ccount4 error")
                raise SystemExit(0)
            yield factory.Cqueue4.put(1)
            factory.pc4 += 1
            x4.append(float(env.now))
            y4.append(factory.Cqueue4.level)

    def Cprocess5(env,factory):
        while True:
            yield factory.Cqueue4.get(1)
            if factory.Ccount5 == 1:
                yield env.timeout(model1_process5_time)
                factory.Ccount5 += 1
            elif factory.Ccount5 == 2:
                yield env.timeout(model2_process5_time)
                factory.Ccount5 += 1
            elif factory.Ccount5 == 3:
                yield env.timeout(model3_process5_time)
                factory.Ccount5 = 1
            else:
                print("Ccount5 error")
                raise SystemExit(0)
            yield factory.Cqueue5.put(1)
            factory.pc5 += 1
            x5.append(float(env.now))
            y5.append(factory.Cqueue5.level)

    def Cprocess6(env,factory):
        while True:
            yield factory.Cqueue3.get(1)
            if factory.Ccount6 == 1:
                yield env.timeout(model1_process6_time)
                factory.Ccount6 += 1
            elif factory.Ccount6 == 2:
                yield env.timeout(model2_process6_time)
                factory.Ccount6 += 1
            elif factory.Ccount6 == 3:
                yield env.timeout(model3_process6_time)
                factory.Ccount6 = 1
            else:
                print("count6 error")
                raise SystemExit(0)
            yield factory.Cqueue6.put(1)
            factory.pc6 += 1
            x6.append(float(env.now))
            y6.append(factory.Cqueue6.level)

    def Cprocess7(env,factory):
        while True:
            yield factory.Cqueue2.get(1)
            if factory.Ccount7 == 1:
                yield env.timeout(model1_process7_time)
                factory.Ccount7 += 1
            elif factory.Ccount7 == 2:
                yield env.timeout(model2_process7_time)
                factory.Ccount7 += 1
            elif factory.Ccount7 == 3:
                yield env.timeout(model3_process7_time)
                factory.Ccount7 = 1
            else:
                print("Ccount7 error")
                raise SystemExit(0)
            yield factory.Cqueue7.put(1)
            factory.pc7 += 1
            x7.append(float(env.now))
            y7.append(factory.Cqueue7.level)

    def Cprocess8(env,factory):
        while True:
            yield factory.Cqueue7.get(1)
            if factory.Ccount8 == 1:
                yield env.timeout(model1_process8_time)
                factory.Ccount8 += 1
            elif factory.Ccount8 == 2:
                yield env.timeout(model2_process8_time)
                factory.Ccount8+= 1
            elif factory.Ccount8 == 3:
                yield env.timeout(model3_process8_time)
                factory.Ccount8 = 1
            else:
                print("Ccount8 error")
                raise SystemExit(0)
            yield factory.Cqueue8.put(1)
            factory.pc8 += 1
            x8.append(float(env.now))
            y8.append(factory.Cqueue8.level)

    def Cprocess9(env,factory):
        while True:
            yield factory.Cqueue7.get(1)
            if factory.Ccount9 == 1:
                yield env.timeout(model1_process9_time)
                factory.Ccount9 += 1
            elif factory.Ccount9 == 2:
                yield env.timeout(model2_process9_time)
                factory.Ccount9 += 1
            elif factory.Ccount9 == 3:
                yield env.timeout(model3_process9_time)
                factory.Ccount9 = 1
            else:
                print("Ccount9 error")
                raise SystemExit(0)
            yield factory.Cqueue9.put(1)
            factory.pc9 += 1
            x9.append(float(env.now))
            y9.append(factory.Cqueue9.level)

    def Cprocess10(env,factory):
        while True:
            yield factory.Cqueue8.get(1)
            yield factory.Cqueue9.get(1)
            if factory.Ccount10 == 1:
                yield env.timeout(model1_process10_time)
                factory.Ccount10 += 1
            elif factory.Ccount10 == 2:
                yield env.timeout(model2_process10_time)
                factory.Ccount10 += 1
            elif factory.Ccount10 == 3:
                yield env.timeout(model3_process10_time)
                factory.Ccount10 = 1
            else:
                print("Ccount10 error")
                raise SystemExit(0)
            yield factory.Cqueue10.put(1)
            factory.pc10 += 1
            x10.append(float(env.now))
            y10.append(factory.Cqueue10.level)

    def Cprocess11(env,factory):
        while True:
            yield factory.Cqueue6.get(1)
            if factory.Ccount11 == 1:
                yield env.timeout(model1_process11_time)
                factory.Ccount11 += 1
            elif factory.Ccount11 == 2:
                yield env.timeout(model2_process11_time)
                factory.Ccount11 += 1
            elif factory.Ccount11 == 3:
                yield env.timeout(model3_process11_time)
                factory.Ccount11 = 1
            else:
                print("Ccount11 error")
                raise SystemExit(0)
            yield factory.Cqueue11.put(1)
            factory.pc11 += 1
            x11.append(float(env.now))
            y11.append(factory.Cqueue11.level)

    def Cprocess12(env,factory):
        while True:
            yield factory.Cqueue5.get(1)
            if factory.Ccount12 == 1:
                yield env.timeout(model1_process12_time)
                factory.Ccount12 += 1
            elif factory.Ccount12 == 2:
                yield env.timeout(model2_process12_time)
                factory.Ccount12 += 1
            elif factory.Ccount12 == 3:
                yield env.timeout(model3_process12_time)
                factory.Ccount12 = 1
            else:
                print("Ccount12 error")
                raise SystemExit(0)
            yield factory.Cqueue12.put(1)
            factory.pc12 += 1
            x12.append(float(env.now))
            y12.append(factory.Cqueue12.level)

    def Cprocess13(env,factory):
        while True:
            yield factory.Cqueue5.get(1)
            if factory.Ccount13 == 1:
                yield env.timeout(model1_process13_time)
                factory.Ccount13 += 1
            elif factory.Ccount13 == 2:
                yield env.timeout(model2_process13_time)
                factory.Ccount13 += 1
            elif factory.Ccount13 == 3:
                yield env.timeout(model3_process13_time)
                factory.Ccount13 = 1
            else:
                print("Ccount13 error")
                raise SystemExit(0)
            yield factory.Cqueue13.put(1)
            factory.pc13 += 1
            x13.append(float(env.now))
            y13.append(factory.Cqueue13.level)


    def Cprocess14(env,factory):
        while True:
            yield factory.Cqueue11.get(1)
            yield factory.Cqueue13.get(1)
            if factory.Ccount14 == 1:
                yield env.timeout(model1_process14_time)
                factory.Ccount14 += 1
            elif factory.Ccount14 == 2:
                yield env.timeout(model2_process14_time)
                factory.Ccount14 += 1
            elif factory.Ccount14 == 3:
                yield env.timeout(model3_process14_time)
                factory.Ccount14 = 1
            else:
                print("Ccount14 error")
                raise SystemExit(0)
            yield factory.Cqueue14.put(1)
            factory.pc14 += 1
            x14.append(float(env.now))
            y14.append(factory.Cqueue14.level)

    def Cprocess15(env,factory):
        while True:
            yield factory.Cqueue12.get(1)
            if factory.Ccount15 == 1:
                yield env.timeout(model1_process15_time)
                factory.Ccount15 += 1
            elif factory.Ccount15 == 2:
                yield env.timeout(model2_process15_time)
                factory.Ccount15 += 1
            elif factory.Ccount15 == 3:
                yield env.timeout(model3_process15_time)
                factory.Ccount15 = 1
            else:
                print("Ccount15 error")
                raise SystemExit(0)
            yield factory.Cqueue15.put(1)
            factory.pc15 += 1
            x15.append(float(env.now))
            y15.append(factory.Cqueue15.level)


    def Cprocess16(env,factory):
        while True:
            yield factory.Cqueue10.get(1)
            if factory.Ccount16 == 1:
                yield env.timeout(model1_process16_time)
                factory.Ccount16 += 1
            elif factory.Ccount16 == 2:
                yield env.timeout(model2_process16_time)
                factory.Ccount16 += 1
            elif factory.Ccount16 == 3:
                yield env.timeout(model3_process16_time)
                factory.Ccount16 = 1
            else:
                print("Ccount16 error")
                raise SystemExit(0)
            yield factory.Cqueue16.put(1)
            factory.pc16 += 1
            x16.append(float(env.now))
            y16.append(factory.Cqueue16.level)

    def Cprocess17(env,factory):
        while True:
            yield factory.Cqueue15.get(1)
            yield factory.Cqueue14.get(1)
            if factory.Ccount17 == 1:
                yield env.timeout(model1_process17_time)
                factory.Ccount17 += 1
            elif factory.Ccount17 == 2:
                yield env.timeout(model2_process17_time)
                factory.Ccount17 += 1
            elif factory.Ccount17 == 3:
                yield env.timeout(model3_process17_time)
                factory.Ccount17 = 1
            else:
                print("Ccount17 error")
                raise SystemExit(0)
            yield factory.Cqueue17.put(1)
            factory.pc17 += 1
            x17.append(float(env.now))
            y17.append(factory.Cqueue17.level)

    def Cprocess18(env,factory):
        while True:
            yield factory.Cqueue16.get(1)
            if factory.Ccount18 == 1:
                yield env.timeout(model1_process18_time)
                factory.Ccount18 += 1
            elif factory.Ccount18 == 2:
                yield env.timeout(model2_process18_time)
                factory.Ccount18 += 1
            elif factory.Ccount18 == 3:
                yield env.timeout(model3_process18_time)
                factory.Ccount18 = 1
            else:
                print("Ccount18 error")
                raise SystemExit(0)
            yield factory.Cqueue18.put(1)
            factory.pc18 += 1
            x18.append(float(env.now))
            y18.append(factory.Cqueue18.level)

    def Cprocess19(env,factory):
        while True:
            yield factory.Cqueue18.get(1)
            if factory.Ccount19 == 1:
                yield env.timeout(model1_process19_time)
                factory.Ccount19 += 1
            elif factory.Ccount19 == 2:
                yield env.timeout(model2_process19_time)
                factory.Ccount19 += 1
            elif factory.Ccount19 == 3:
                yield env.timeout(model3_process19_time)
                factory.Ccount19 = 1
            else:
                print("Ccount19 error")
                raise SystemExit(0)
            yield factory.Cqueue19.put(1)
            factory.pc19 += 1
            x19.append(float(env.now))
            y19.append(factory.Cqueue19.level)


    def Cprocess20(env,factory):
        while True:
            yield factory.Cqueue18.get(1)
            if factory.Ccount20 == 1:
                yield env.timeout(model1_process20_time)
                factory.Ccount20 += 1
            elif factory.Ccount20 == 2:
                yield env.timeout(model2_process20_time)
                factory.Ccount20 += 1
            elif factory.Ccount20 == 3:
                yield env.timeout(model3_process20_time)
                factory.Ccount20 = 1
            else:
                print("Ccount20 error")
                raise SystemExit(0)
            yield factory.Cqueue20.put(1)
            factory.pc20 += 1
            x20.append(float(env.now))
            y20.append(factory.Cqueue20.level)

    def Cprocess21(env,factory):
        while True:
            yield factory.Cqueue17.get(1)
            if factory.Ccount21 == 1:
                yield env.timeout(model1_process21_time)
                factory.Ccount21 += 1
            elif factory.Ccount21 == 2:
                yield env.timeout(model2_process21_time)
                factory.Ccount21 += 1
            elif factory.Ccount21 == 3:
                yield env.timeout(model3_process21_time)
                factory.Ccount21 = 1
            else:
                print("Ccount21 error")
                raise SystemExit(0)
            yield factory.Cqueue21.put(1)
            factory.pc21 += 1
            x21.append(float(env.now))
            y21.append(factory.Cqueue21.level)

    def Cprocess22(env,factory):
        while True:
            yield factory.Cqueue17.get(1)
            if factory.Ccount22 == 1:
                yield env.timeout(model1_process22_time)
                factory.Ccount22 += 1
            elif factory.Ccount22 == 2:
                yield env.timeout(model2_process22_time)
                factory.Ccount22 += 1
            elif factory.Ccount22 == 3:
                yield env.timeout(model3_process22_time)
                factory.Ccount22 = 1
            else:
                print("Ccount22 error")
                raise SystemExit(0)
            yield factory.Cqueue22.put(1)
            factory.pc22 += 1
            x22.append(float(env.now))
            y22.append(factory.Cqueue22.level)

    def Cprocess23(env,factory):
        while True:
            yield factory.Cqueue22.get(1)
            yield factory.Cqueue21.get(1)
            if factory.Ccount23 == 1:
                yield env.timeout(model1_process23_time)
                factory.Ccount23 += 1
            elif factory.Ccount23 == 2:
                yield env.timeout(model2_process23_time)
                factory.Ccount23 += 1
            elif factory.Ccount23 == 3:
                yield env.timeout(model3_process23_time)
                factory.Ccount23 = 1
            else:
                print("Ccount23 error")
                raise SystemExit(0)
            yield factory.Cqueue23.put(1)
            factory.pc23 += 1
            x23.append(float(env.now))
            y23.append(factory.Cqueue23.level)

    def Cprocess24(env,factory):
        while True:
            yield factory.Cqueue21.get(1)
            if factory.Ccount24 == 1:
                yield env.timeout(model1_process24_time)
                factory.Ccount24 += 1
            elif factory.Ccount24 == 2:
                yield env.timeout(model2_process24_time)
                factory.Ccount24 += 1
            elif factory.Ccount24 == 3:
                yield env.timeout(model3_process24_time)
                factory.Ccount24 = 1
            else:
                print("Ccount24 error")
                raise SystemExit(0)
            yield factory.Cqueue24.put(1)
            factory.pc24 += 1
            x24.append(float(env.now))
            y24.append(factory.Cqueue24.level)

    def Cprocess25(env,factory):
        while True:
            yield factory.Cqueue19.get(1)
            yield factory.Cqueue20.get(1)
            if factory.Ccount25 == 1:
                yield env.timeout(model1_process25_time)
                factory.Ccount25 += 1
            elif factory.Ccount25 == 2:
                yield env.timeout(model2_process25_time)
                factory.Ccount25 += 1
            elif factory.Ccount25 == 3:
                yield env.timeout(model3_process25_time)
                factory.Ccount25 = 1
            else:
                print("Ccount25 error")
                raise SystemExit(0)
            yield factory.Cqueue25.put(1)
            factory.pc25 += 1
            x25.append(float(env.now))
            y25.append(factory.Cqueue25.level)

    def Cprocess26(env,factory):
        while True:
            yield factory.Cqueue25.get(1)
            if factory.Ccount26 == 1:
                yield env.timeout(model1_process26_time)
                factory.Ccount26 += 1
            elif factory.Ccount26 == 2:
                yield env.timeout(model2_process26_time)
                factory.Ccount26 += 1
            elif factory.Ccount26 == 3:
                yield env.timeout(model3_process26_time)
                factory.Ccount26 = 1
            else:
                print("Ccount26 error")
                raise SystemExit(0)
            yield factory.Cqueue26.put(1)
            factory.pc26 += 1
            x26.append(float(env.now))
            y26.append(factory.Cqueue26.level)

    def Cprocess27(env,factory):
        while True:
            yield factory.Cqueue25.get(1)
            if factory.Ccount27 == 1:
                yield env.timeout(model1_process27_time)
                factory.Ccount27 += 1
            elif factory.Ccount27 == 2:
                yield env.timeout(model2_process27_time)
                factory.Ccount27 += 1
            elif factory.Ccount27 == 3:
                yield env.timeout(model3_process27_time)
                factory.Ccount27 = 1
            else:
                print("Ccount27 error")
                raise SystemExit(0)
            yield factory.Cqueue27.put(1)
            factory.pc27 += 1
            x27.append(float(env.now))
            y27.append(factory.Cqueue27.level)

    def Cprocess28(env,factory):
        while True:
            yield factory.Cqueue25.get(1)
            if factory.Ccount28 == 1:
                yield env.timeout(model1_process28_time)
                factory.Ccount28 += 1
            elif factory.Ccount28 == 2:
                yield env.timeout(model2_process28_time)
                factory.Ccount28 += 1
            elif factory.Ccount28 == 3:
                yield env.timeout(model3_process28_time)
                factory.Ccount2 = 1
            else:
                print("Ccount28 error")
                raise SystemExit(0)
            yield factory.Cqueue28.put(1)
            factory.pc28 += 1
            x28.append(float(env.now))
            y28.append(factory.Cqueue28.level)


    def Cprocess29(env,factory):
        while True:
            yield factory.Cqueue28.get(1)
            yield factory.Cqueue24.get(1)
            if factory.Ccount29 == 1:
                yield env.timeout(model1_process29_time)
                factory.Ccount29 += 1
            elif factory.Ccount29 == 2:
                yield env.timeout(model2_process29_time)
                factory.Ccount29 += 1
            elif factory.Ccount29 == 3:
                yield env.timeout(model3_process29_time)
                factory.Ccount29 = 1
            else:
                print("Ccount29 error")
                raise SystemExit(0)
            yield factory.Cqueue29.put(1)
            factory.pc29 += 1
            x29.append(float(env.now))
            y29.append(factory.Cqueue29.level)

    def Cprocess30(env,factory):
        while True:
            yield factory.Cqueue23.get(1)
            if factory.Ccount30 == 1:
                yield env.timeout(model1_process30_time)
                factory.Ccount30 += 1
            elif factory.Ccount30 == 2:
                yield env.timeout(model2_process30_time)
                factory.Ccount30 += 1
            elif factory.Ccount30 == 3:
                yield env.timeout(model3_process30_time)
                factory.Ccount30 = 1
            else:
                print("Ccount30 error")
                raise SystemExit(0)
            yield factory.Cqueue30.put(1)
            factory.pc30 += 1
            x30.append(float(env.now))
            y30.append(factory.Cqueue30.level)


    def Cprocess31(env,factory):
        while True:
            yield factory.Cqueue30.get(1)
            if factory.Ccount31 == 1:
                yield env.timeout(model1_process31_time)
                factory.Ccount31 += 1
            elif factory.Ccount31 == 2:
                yield env.timeout(model2_process31_time)
                factory.Ccount31 += 1
            elif factory.Ccount31 == 3:
                yield env.timeout(model3_process31_time)
                factory.Ccount31 = 1
            else:
                print("Ccount31 error")
                raise SystemExit(0)
            yield factory.Cqueue31.put(1)
            factory.pc31 += 1
            x31.append(float(env.now))
            y31.append(factory.Cqueue31.level)


    def Cprocess32(env,factory):
        while True:
            yield factory.Cqueue27.get(1)
            if factory.Ccount32 == 1:
                yield env.timeout(model1_process32_time)
                factory.Ccount32 += 1
            elif factory.Ccount32 == 2:
                yield env.timeout(model2_process32_time)
                factory.Ccount32 += 1
            elif factory.Ccount32 == 3:
                yield env.timeout(model3_process32_time)
                factory.Ccount32 = 1
            else:
                print("Ccount32 error")
                raise SystemExit(0)
            yield factory.Cqueue32.put(1)
            factory.pc32 += 1
            x32.append(float(env.now))
            y32.append(factory.Cqueue32.level)

    def Cprocess33(env,factory):
        while True:
            yield factory.Cqueue26.get(1)
            if factory.Ccount33 == 1:
                yield env.timeout(model1_process33_time)
                factory.Ccount33 += 1
            elif factory.Ccount33 == 2:
                yield env.timeout(model2_process33_time)
                factory.Ccount33 += 1
            elif factory.Ccount33 == 3:
                yield env.timeout(model3_process33_time)
                factory.Ccount33 = 1
            else:
                print("Ccount33 error")
                raise SystemExit(0)
            yield factory.Cqueue33.put(1)
            factory.pc33 += 1
            x33.append(float(env.now))
            y33.append(factory.Cqueue33.level)

    def Cprocess34(env,factory):
        while True:
            yield factory.Cqueue32.get(1)
            yield factory.Cqueue29.get(1)
            if factory.Ccount34 == 1:
                yield env.timeout(model1_process34_time)
                factory.Ccount34 += 1
            elif factory.Ccount34 == 2:
                yield env.timeout(model2_process34_time)
                factory.Ccount34 += 1
            elif factory.Ccount34 == 3:
                yield env.timeout(model3_process34_time)
                factory.Ccount34 = 1
            else:
                print("Ccount34 error")
                raise SystemExit(0)
            yield factory.Cqueue34.put(1)
            factory.pc34 += 1
            x34.append(float(env.now))
            y34.append(factory.Cqueue34.level)

    def Cprocess35(env,factory):
        while True:
            yield factory.Cqueue31.get(1)
            if factory.Ccount35 == 1:
                yield env.timeout(model1_process35_time)
                factory.Ccount35 += 1
            elif factory.Ccount35 == 2:
                yield env.timeout(model2_process35_time)
                factory.Ccount35 += 1
            elif factory.Ccount35 == 3:
                yield env.timeout(model3_process35_time)
                factory.Ccount35 = 1
            else:
                print("Ccount35 error")
                raise SystemExit(0)
            yield factory.Cqueue35.put(1)
            factory.pc35 += 1
            x35.append(float(env.now))
            y35.append(factory.Cqueue35.level)

    def Cprocess36(env,factory):
        while True:
            yield factory.Cqueue35.get(1)
            yield factory.Cqueue34.get(1)
            if factory.Ccount36 == 1:
                yield env.timeout(model1_process36_time)
                factory.Ccount36 += 1
            elif factory.Ccount36 == 2:
                yield env.timeout(model2_process36_time)
                factory.Ccount36 += 1
            elif factory.Ccount36 == 3:
                yield env.timeout(model3_process36_time)
                factory.Ccount36 = 1
            else:
                print("Ccount36 error")
                raise SystemExit(0)
            yield factory.Cqueue36.put(1)
            factory.pc36 += 1
            x36.append(float(env.now))
            y36.append(factory.Cqueue36.level)

    def Cprocess37(env,factory):
        while True:
            yield factory.Cqueue32.get(1)
            if factory.Ccount37 == 1:
                yield env.timeout(model1_process37_time)
                factory.Ccount37 += 1
            elif factory.Ccount37 == 2:
                yield env.timeout(model2_process37_time)
                factory.Ccount37 += 1
            elif factory.Ccount37 == 3:
                yield env.timeout(model3_process37_time)
                factory.Ccount37 = 1
            else:
                print("Ccount37 error")
                raise SystemExit(0)
            yield factory.Cqueue37.put(1)
            factory.pc37 += 1
            x37.append(float(env.now))
            y37.append(factory.Cqueue37.level)

    def Cprocess38(env,factory):
        while True:
            yield factory.Cqueue33.get(1)
            if factory.Ccount38 == 1:
                yield env.timeout(model1_process38_time)
                factory.Ccount38 += 1
            elif factory.Ccount38 == 2:
                yield env.timeout(model2_process38_time)
                factory.Ccount38 += 1
            elif factory.Ccount38 == 3:
                yield env.timeout(model3_process38_time)
                factory.Ccount38 = 1
            else:
                print("Ccount38 error")
                raise SystemExit(0)
            yield factory.Cqueue38.put(1)
            factory.pc38 += 1
            x38.append(float(env.now))
            y38.append(factory.Cqueue38.level)

    def Cprocess39(env,factory):
        while True:
            yield factory.Cqueue38.get(1)
            if factory.Ccount39 == 1:
                yield env.timeout(model1_process39_time)
                factory.Ccount39 += 1
            elif factory.Ccount39 == 2:
                yield env.timeout(model2_process39_time)
                factory.Ccount39 += 1
            elif factory.Ccount39 == 3:
                yield env.timeout(model3_process39_time)
                factory.Ccount39 = 1
            else:
                print("Ccount39 error")
                raise SystemExit(0)
            yield factory.Cqueue39.put(1)
            factory.pc39 += 1
            x39.append(float(env.now))
            y39.append(factory.Cqueue39.level)

    def Cprocess40(env,factory):
        while True:
            yield factory.Cqueue36.get(1)
            if factory.Ccount40 == 1:
                yield env.timeout(model1_process40_time)
                factory.Ccount40 += 1
            elif factory.Ccount40 == 2:
                yield env.timeout(model2_process40_time)
                factory.Ccount40 += 1
            elif factory.Ccount40 == 3:
                yield env.timeout(model3_process40_time)
                factory.Ccount40 = 1
            else:
                print("Ccount40 error")
                raise SystemExit(0)
            yield factory.Cqueue40.put(1)
            factory.pc40 += 1
            x40.append(float(env.now))
            y40.append(factory.Cqueue40.level)



    def Cprocess41(env,factory):
        while True:
            yield factory.Cqueue37.get(1)
            yield factory.Cqueue39.get(1)
            yield factory.Cqueue40.get(1)
            if factory.Ccount41 == 1:
                factory.Ccount41 += 1
                factory.model1 += 1
            elif factory.Ccount41 == 2:
                factory.Ccount41 += 1
                factory.model2 += 1
            elif factory.Ccount41 == 3:
                factory.Ccount41 = 1
                factory.model3 +=1
            else:
                print("Bcount40 error")
                raise SystemExit(0)
            yield factory.dispatch.put(1)
            factory.pc41 += 1
            x41.append(float(env.now))
            y41.append(factory.dispatch.level)

    process1_process = env.process(process1(env, factory))
    process2_process = env.process(process2(env, factory))
    process3_process = env.process(process3(env, factory))
    process4_process = env.process(process4(env, factory))
    process5_process = env.process(process5(env, factory))
    process6_process = env.process(process6(env, factory))
    process7_process = env.process(process7(env, factory))
    process8_process = env.process(process8(env, factory))
    process9_process = env.process(process9(env, factory))
    process10_process = env.process(process10(env, factory))
    process11_process = env.process(process11(env, factory))
    process12_process = env.process(process12(env, factory))
    process13_process = env.process(process13(env, factory))
    process14_process = env.process(process14(env, factory))
    process15_process = env.process(process15(env, factory))
    process16_process = env.process(process16(env, factory))
    process17_process = env.process(process17(env, factory))
    process18_process = env.process(process18(env, factory))
    process19_process = env.process(process19(env, factory))
    process20_process = env.process(process20(env, factory))
    process21_process = env.process(process21(env, factory))
    process22_process = env.process(process22(env, factory))
    process23_process = env.process(process23(env, factory))
    process24_process = env.process(process24(env, factory))
    process25_process = env.process(process25(env, factory))
    process26_process = env.process(process26(env, factory))
    process27_process = env.process(process27(env, factory))
    process28_process = env.process(process28(env, factory))
    process29_process = env.process(process29(env, factory))
    process30_process = env.process(process30(env, factory))
    process31_process = env.process(process31(env, factory))
    process32_process = env.process(process32(env, factory))
    process33_process = env.process(process33(env, factory))
    process34_process = env.process(process34(env, factory))
    process35_process = env.process(process35(env, factory))
    process36_process = env.process(process36(env, factory))
    process37_process = env.process(process37(env, factory))
    process38_process = env.process(process38(env, factory))
    process39_process = env.process(process39(env, factory))
    process40_process = env.process(process40(env, factory))
    process41_process = env.process(process41(env, factory))
    process1B_process = env.process(Bprocess1(env, factory))
    process2B_process = env.process(Bprocess2(env, factory))
    process3B_process = env.process(Bprocess3(env, factory))
    process4B_process = env.process(Bprocess4(env, factory))
    process5B_process = env.process(Bprocess5(env, factory))
    process6B_process = env.process(Bprocess6(env, factory))
    process7B_process = env.process(Bprocess7(env, factory))
    process8B_process = env.process(Bprocess8(env, factory))
    process9B_process = env.process(Bprocess9(env, factory))
    process10B_process = env.process(Bprocess10(env, factory))
    process11B_process = env.process(Bprocess11(env, factory))
    process12B_process = env.process(Bprocess12(env, factory))
    process13B_process = env.process(Bprocess13(env, factory))
    process14B_process = env.process(Bprocess14(env, factory))
    process15B_process = env.process(Bprocess15(env, factory))
    process16B_process = env.process(Bprocess16(env, factory))
    process17B_process = env.process(Bprocess17(env, factory))
    process18B_process = env.process(Bprocess18(env, factory))
    process19B_process = env.process(Bprocess19(env, factory))
    process20B_process = env.process(Bprocess20(env, factory))
    process21B_process = env.process(Bprocess21(env, factory))
    process22B_process = env.process(Bprocess22(env, factory))
    process23B_process = env.process(Bprocess23(env, factory))
    process24B_process = env.process(Bprocess24(env, factory))
    process25B_process = env.process(Bprocess25(env, factory))
    process26B_process = env.process(Bprocess26(env, factory))
    process27B_process = env.process(Bprocess27(env, factory))
    process28B_process = env.process(Bprocess28(env, factory))
    process29B_process = env.process(Bprocess29(env, factory))
    process30B_process = env.process(Bprocess30(env, factory))
    process31B_process = env.process(Bprocess31(env, factory))
    process32B_process = env.process(Bprocess32(env, factory))
    process33B_process = env.process(Bprocess33(env, factory))
    process34B_process = env.process(Bprocess34(env, factory))
    process35B_process = env.process(Bprocess35(env, factory))
    process36B_process = env.process(Bprocess36(env, factory))
    process37B_process = env.process(Bprocess37(env, factory))
    process38B_process = env.process(Bprocess38(env, factory))
    process39B_process = env.process(Bprocess39(env, factory))
    process40B_process = env.process(Bprocess40(env, factory))
    process41B_process = env.process(Bprocess41(env, factory))
    process1C_process = env.process(Cprocess1(env, factory))
    process2C_process = env.process(Cprocess2(env, factory))
    process3C_process = env.process(Cprocess3(env, factory))
    process4C_process = env.process(Cprocess4(env, factory))
    process5C_process = env.process(Cprocess5(env, factory))
    process6C_process = env.process(Cprocess6(env, factory))
    process7C_process = env.process(Cprocess7(env, factory))
    process8C_process = env.process(Cprocess8(env, factory))
    process9C_process = env.process(Cprocess9(env, factory))
    process10C_process = env.process(Cprocess10(env, factory))
    process11C_process = env.process(Cprocess11(env, factory))
    process12C_process = env.process(Cprocess12(env, factory))
    process13C_process = env.process(Cprocess13(env, factory))
    process14C_process = env.process(Cprocess14(env, factory))
    process15C_process = env.process(Cprocess15(env, factory))
    process16C_process = env.process(Cprocess16(env, factory))
    process17C_process = env.process(Cprocess17(env, factory))
    process18C_process = env.process(Cprocess18(env, factory))
    process19C_process = env.process(Cprocess19(env, factory))
    process20C_process = env.process(Cprocess20(env, factory))
    process21C_process = env.process(Cprocess21(env, factory))
    process22C_process = env.process(Cprocess22(env, factory))
    process23C_process = env.process(Cprocess23(env, factory))
    process24C_process = env.process(Cprocess24(env, factory))
    process25C_process = env.process(Cprocess25(env, factory))
    process26C_process = env.process(Cprocess26(env, factory))
    process27C_process = env.process(Cprocess27(env, factory))
    process28C_process = env.process(Cprocess28(env, factory))
    process29C_process = env.process(Cprocess29(env, factory))
    process30C_process = env.process(Cprocess30(env, factory))
    process31C_process = env.process(Cprocess31(env, factory))
    process32C_process = env.process(Cprocess32(env, factory))
    process33C_process = env.process(Cprocess33(env, factory))
    process34C_process = env.process(Cprocess34(env, factory))
    process35C_process = env.process(Cprocess35(env, factory))
    process36C_process = env.process(Cprocess36(env, factory))
    process37C_process = env.process(Cprocess37(env, factory))
    process38C_process = env.process(Cprocess38(env, factory))
    process39C_process = env.process(Cprocess39(env, factory))
    process40C_process = env.process(Cprocess40(env, factory))
    process41C_process = env.process(Cprocess41(env, factory))
    env.run(until=total_time)
    end = timer()
    t = (end - start)
    # print(f'%d parts in queue1' % factory.queue1.level)
    # print(f'%d parts in queue2' % factory.queue2.level)
    # print(f'%d parts in queue3' % factory.queue3.level)
    # print(f'%d parts in queue4' % factory.queue4.level)
    # print(f'%d parts in queue5' % factory.queue5.level)
    # print(f'%d parts in queue6' % factory.queue6.level)
    # print(f'%d parts in queue7' % factory.queue7.level)
    # print(f'%d parts in queue8' % factory.queue8.level)
    # print(f'%d parts in queue9' % factory.queue9.level)
    # print(f'%d parts in queue10' % factory.queue10.level)
    # print(f'%d parts in queue11' % factory.queue11.level)
    # print(f'%d parts in queue12' % factory.queue12.level)
    # print(f'%d parts in queue13' % factory.queue13.level)
    # print(f'%d parts in queue14' % factory.queue14.level)
    # print(f'%d parts in queue15' % factory.queue15.level)
    # print(f'%d parts in queue16' % factory.queue16.level)
    # print(f'%d parts in queue17' % factory.queue17.level)
    # print(f'%d parts in queue18' % factory.queue18.level)
    # print(f'%d parts in queue19' % factory.queue19.level)
    # print(f'%d parts in queue20' % factory.queue20.level)
    # print(f'%d parts in queue21' % factory.queue21.level)
    # print(f'%d parts in queue22' % factory.queue22.level)
    # print(f'%d parts in queue23' % factory.queue23.level)
    # print(f'%d parts in queue24' % factory.queue24.level)
    # print(f'%d parts in queue25' % factory.queue25.level)
    # print(f'%d parts in queue26' % factory.queue26.level)
    # print(f'%d parts in queue27' % factory.queue27.level)
    # print(f'%d parts in queue28' % factory.queue28.level)
    # print(f'%d parts in queue29' % factory.queue29.level)
    # print(f'%d parts in queue30' % factory.queue30.level)
    # print(f'%d parts in queue31' % factory.queue31.level)
    # print(f'%d parts in queue32' % factory.queue32.level)
    # print(f'%d parts in queue33' % factory.queue33.level)
    # print(f'%d parts in queue34' % factory.queue34.level)
    # print(f'%d parts in queue35' % factory.queue35.level)
    # print(f'%d parts in queue36' % factory.queue36.level)
    # print(f'%d parts in queue37' % factory.queue37.level)
    # print(f'%d parts in queue38' % factory.queue38.level)
    # print(f'%d parts in queue39' % factory.queue39.level)
    # print(f'%d parts in queue40' % factory.queue40.level)
    # print(f'%d parts in queue41' % factory.queue41.level)
    # print(f'%d parts in queue' % factory.Bqueue1.level)
    # print(f'%d parts in queue' % factory.Bqueue2.level)
    # print(f'%d parts in queue' % factory.Bqueue3.level)
    # print(f'%d parts in queue' % factory.Bqueue4.level)
    # print(f'%d parts in queue' % factory.Bqueue5.level)
    # print(f'%d parts in queue' % factory.Bqueue6.level)
    # print(f'%d parts in queue' % factory.Bqueue7.level)
    # print(f'%d parts in queue' % factory.Bqueue8.level)
    # print(f'%d parts in queue' % factory.Bqueue9.level)
    # print(f'%d parts in queue' % factory.Bqueue10.level)
    # print(f'%d parts in queue' % factory.Bqueue11.level)
    # print(f'%d parts in queue' % factory.Bqueue12.level)
    # print(f'%d parts in queue' % factory.Bqueue13.level)
    # print(f'%d parts in queue' % factory.Bqueue14.level)
    # print(f'%d parts in queue' % factory.Bqueue15.level)
    # print(f'%d parts in queue' % factory.Bqueue16.level)
    # print(f'%d parts in queue' % factory.Bqueue17.level)
    # print(f'%d parts in queue' % factory.Bqueue18.level)
    # print(f'%d parts in queue' % factory.Bqueue19.level)
    # print(f'%d parts in queue' % factory.Bqueue20.level)
    # print(f'%d parts in queue' % factory.Bqueue21.level)
    # print(f'%d parts in queue' % factory.Bqueue22.level)
    # print(f'%d parts in queue' % factory.Bqueue23.level)
    # print(f'%d parts in queue' % factory.Bqueue24.level)
    # print(f'%d parts in queue' % factory.Bqueue25.level)
    # print(f'%d parts in queue' % factory.Bqueue26.level)
    # print(f'%d parts in queue' % factory.Bqueue27.level)
    # print(f'%d parts in queue' % factory.Bqueue28.level)
    # print(f'%d parts in queue' % factory.Bqueue29.level)
    # print(f'%d parts in queue' % factory.Bqueue30.level)
    # print(f'%d parts in queue' % factory.Bqueue31.level)
    # print(f'%d parts in queue' % factory.Bqueue32.level)
    # print(f'%d parts in queue' % factory.Bqueue33.level)
    # print(f'%d parts in queue' % factory.Bqueue34.level)
    # print(f'%d parts in queue' % factory.Bqueue35.level)
    # print(f'%d parts in queue' % factory.Bqueue36.level)
    # print(f'%d parts in queue' % factory.Bqueue37.level)
    # print(f'%d parts in queue' % factory.Bqueue38.level)
    # print(f'%d parts in queue' % factory.Bqueue39.level)
    # print(f'%d parts in queue' % factory.Bqueue40.level)
    #
    print(f'Dispatch has %d parts ready to go!' % factory.dispatch.level)
    print('Total quatity make up = ',factory.model1,'Model_1', factory.model2, 'Model_2', factory.model3, 'Model_3')
    # #
    # print(f'----------------------------------')
    print("simulation time =",t)
    #
    print(f'SIMULATION COMPLETED')
    #
    # arr = (x1, y1, x2, y2, x3, y3, x4, y4, x5, y5, x6, y6, x7, y7, x8, y8, x9, y9,
    #        x10, y10, x11, y11, x12, y12, x13, y13, x14, y14, x15, y15, x16, y16, x17, y17, x18, y18, x19, y19,
    #        x20, y20, x21, y21, x22, y22, x23, y23, x24, y24, x25, y25, x26, y26, x27, y27, x28, y28, x29, y29,
    #        x30, y30, x31, y31, x32, y32, x33, y33, x34, y34, x35, y35, x36, y36, x37, y37, x38, y38, x39, y39,
    #        x40, x40, x41, y41)
    #
    # np.savetxt('TIME_DIST_PLOT_COMP_3_3_MODEL.csv',
    #            arr,
    #            delimiter=", ",
    #            fmt='% s')
    #
    #
    # plt.figure(1)
    # plt.subplot(2,4,1)
    # plt.plot(x1,y1, label= 'Process 1')
    # plt.legend()
    # plt.subplot(2,4,2)
    # plt.plot(x2,y2, label= 'Process 2')
    # plt.legend()
    # plt.subplot(2,4,3)
    # plt.plot(x3,y3, label= 'Process 3')
    # plt.legend()
    # plt.subplot(2,4,4)
    # plt.plot(x4,y4, label= 'Process 4')
    # plt.legend()
    # plt.subplot(2,4,5)
    # plt.plot(x5,y5, label= 'Process 5')
    # plt.legend()
    # plt.subplot(2,4,6)
    # plt.plot(x6,y6, label= 'Process 6')
    # plt.legend()
    # plt.subplot(2,4,7)
    # plt.plot(x7,y7, label= 'Process 7')
    # plt.legend()
    # plt.subplot(2,4,8)
    # plt.plot(x8,y8, label= 'Process 8')
    # plt.legend()
    #
    # plt.figure(2)
    # plt.subplot(2,4,1)
    # plt.plot(x9,y9, label= 'Process 9')
    # plt.legend()
    # plt.subplot(2,4,2)
    # plt.plot(x10,y10, label= 'Process 10')
    # plt.legend()
    # plt.subplot(2,4,3)
    # plt.plot(x11,y11, label= 'Process 11')
    # plt.legend()
    # plt.subplot(2,4,4)
    # plt.plot(x12,y12, label= 'Process 12')
    # plt.legend()
    # plt.subplot(2,4,5)
    # plt.plot(x13,y13, label= 'Process 13')
    # plt.legend()
    # plt.subplot(2,4,6)
    # plt.plot(x14,y14, label= 'Process 14')
    # plt.legend()
    # plt.subplot(2,4,7)
    # plt.plot(x15,y15, label= 'Process 15')
    # plt.legend()
    # plt.subplot(2,4,8)
    # plt.plot(x16,y16, label= 'Process 16')
    # plt.legend()
    #
    # plt.figure(3)
    # plt.subplot(2,4,1)
    # plt.plot(x17,y17, label= 'Process 17')
    # plt.legend()
    # plt.subplot(2,4,2)
    # plt.plot(x18,y18, label= 'Process 18')
    # plt.legend()
    # plt.subplot(2,4,3)
    # plt.plot(x19,y19, label= 'Process 19')
    # plt.legend()
    # plt.subplot(2,4,4)
    # plt.plot(x20,y20, label= 'Process 20')
    # plt.legend()
    # plt.subplot(2,4,5)
    # plt.plot(x21,y21, label= 'Process 21')
    # plt.legend()
    # plt.subplot(2,4,6)
    # plt.plot(x22,y22, label= 'Process 22')
    # plt.legend()
    # plt.subplot(2,4,7)
    # plt.plot(x23,y23, label= 'Process 23')
    # plt.legend()
    # plt.subplot(2,4,8)
    # plt.plot(x24,y24, label= 'Process 24')
    # plt.legend()
    #
    # plt.figure(4)
    # plt.subplot(2,4,1)
    # plt.plot(x25,y25, label= 'Process 25')
    # plt.legend()
    # plt.subplot(2,4,2)
    # plt.plot(x26,y26, label= 'Process 26')
    # plt.legend()
    # plt.subplot(2,4,3)
    # plt.plot(x27,y27, label= 'Process 27')
    # plt.legend()
    # plt.subplot(2,4,4)
    # plt.plot(x28,y28, label= 'Process 28')
    # plt.legend()
    # plt.subplot(2,4,5)
    # plt.plot(x29,y29, label= 'Process 29')
    # plt.legend()
    # plt.subplot(2,4,6)
    # plt.plot(x30,y30, label= 'Process 30')
    # plt.legend()
    # plt.subplot(2,4,7)
    # plt.plot(x31,y31, label= 'Process 31')
    # plt.legend()
    # plt.subplot(2,4,8)
    # plt.plot(x32,y32, label= 'Process 32')
    # plt.legend()
    #
    # plt.figure(5)
    # plt.subplot(2,4,1)
    # plt.plot(x33,y33, label= 'Process 33')
    # plt.legend()
    # plt.subplot(2,4,2)
    # plt.plot(x34,y34, label= 'Process 34')
    # plt.legend()
    # plt.subplot(2,4,3)
    # plt.plot(x35,y35, label= 'Process 35')
    # plt.legend()
    # plt.subplot(2,4,4)
    # plt.plot(x36,y36, label= 'Process 36')
    # plt.legend()
    # plt.subplot(2,4,5)
    # plt.plot(x37,y37, label= 'Process 37')
    # plt.legend()
    # plt.subplot(2,4,6)
    # plt.plot(x38,y38, label= 'Process 38')
    # plt.legend()
    # plt.subplot(2,4,7)
    # plt.plot(x39,y39, label= 'Process 39')
    # plt.legend()
    # plt.subplot(2,4,8)
    # plt.plot(x40,y40, label= 'Process 40')
    # plt.legend()
    # plt.figure(6)
    # plt.plot(x41,y41, label= 'Dispatch')
    # plt.legend()
    #
    #
    # plt.show()
    return t



